-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2018 at 03:35 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ztchat`
--

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_auto_responder`
--

CREATE TABLE `lh_abstract_auto_responder` (
  `id` int(11) NOT NULL,
  `siteaccess` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `timeout_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dep_id` int(11) NOT NULL,
  `only_proactive` int(11) NOT NULL,
  `repeat_number` int(11) NOT NULL DEFAULT '1',
  `survey_timeout` int(11) NOT NULL DEFAULT '0',
  `survey_id` int(11) NOT NULL DEFAULT '0',
  `wait_timeout_hold_1` int(11) NOT NULL,
  `wait_timeout_hold_2` int(11) NOT NULL,
  `wait_timeout_hold_3` int(11) NOT NULL,
  `wait_timeout_hold_4` int(11) NOT NULL,
  `wait_timeout_hold_5` int(11) NOT NULL,
  `timeout_hold_message_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `timeout_hold_message_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `timeout_hold_message_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `timeout_hold_message_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `timeout_hold_message_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_hold` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_2` int(11) NOT NULL,
  `timeout_message_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_3` int(11) NOT NULL,
  `timeout_message_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_4` int(11) NOT NULL,
  `timeout_message_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_5` int(11) NOT NULL,
  `timeout_message_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_reply_1` int(11) NOT NULL,
  `timeout_reply_message_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_reply_2` int(11) NOT NULL,
  `timeout_reply_message_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_reply_3` int(11) NOT NULL,
  `timeout_reply_message_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_reply_4` int(11) NOT NULL,
  `timeout_reply_message_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `wait_timeout_reply_5` int(11) NOT NULL,
  `timeout_reply_message_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `languages` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ignore_pa_chat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_auto_responder_chat`
--

CREATE TABLE `lh_abstract_auto_responder_chat` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `auto_responder_id` int(11) NOT NULL,
  `wait_timeout_send` int(11) NOT NULL,
  `pending_send_status` int(11) NOT NULL,
  `active_send_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_browse_offer_invitation`
--

CREATE TABLE `lh_abstract_browse_offer_invitation` (
  `id` int(11) NOT NULL,
  `siteaccess` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_on_site` int(11) NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `callback_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `lhc_iframe_content` tinyint(4) NOT NULL,
  `custom_iframe_url` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_times` int(11) NOT NULL,
  `url` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  `has_url` int(11) NOT NULL,
  `is_wildcard` int(11) NOT NULL,
  `referrer` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `unit` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_email_template`
--

CREATE TABLE `lh_abstract_email_template` (
  `id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_name_ac` tinyint(4) NOT NULL,
  `from_email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_email_ac` tinyint(4) NOT NULL,
  `user_mail_as_sender` tinyint(4) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bcc_recipients` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_ac` tinyint(4) NOT NULL,
  `reply_to` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reply_to_ac` tinyint(4) NOT NULL,
  `recipient` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_abstract_email_template`
--

INSERT INTO `lh_abstract_email_template` (`id`, `name`, `from_name`, `from_name_ac`, `from_email`, `from_email_ac`, `user_mail_as_sender`, `content`, `subject`, `bcc_recipients`, `subject_ac`, `reply_to`, `reply_to_ac`, `recipient`) VALUES
(1, 'Send mail to user', 'ZTLawFirm', 0, '', 0, 0, 'Dear {user_chat_nick},\r\n\r\n{additional_message}\r\n\r\nZTLawFirm response:\r\n{messages_content}\r\n\r\nSincerely,\r\nZTLawFirm.\r\n', '{name_surname} has responded to your request', '', 1, '', 1, ''),
(2, 'Support request from user', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nUser request data:\r\nName: {name}\r\nEmail: {email}\r\nPhone: {phone}\r\nDepartment: {department}\r\nCountry: {country}\r\nCity: {city}\r\nIP: {ip}\r\n\r\nMessage:\r\n{message}\r\n\r\nAdditional data, if any:\r\n{additional_data}\r\n\r\nURL of page from which user has send request:\r\n{url_request}\r\n\r\nLink to chat if any:\r\n{prefillchat}\r\n\r\nSincerely,\r\nLive Support Team', '{name}, {country}, {department}, Support request from user', '', 0, '', 0, 'muralikumar.krishnamurthy@gmail.com'),
(3, 'User mail for himself', 'ZTLawFirm', 0, '', 0, 0, 'Dear {user_chat_nick},\r\n\r\nTranscript:\r\n{messages_content}\r\nChat ID: {chat_id}\n\r\nSincerely,\r\nLive Support Team\r\n', 'Chat transcript', '', 0, '', 0, ''),
(4, 'New chat request', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nUser request data:\r\nName: {name}\r\nEmail: {email}\r\nPhone: {phone}\r\nDepartment: {department}\r\nCountry: {country}\r\nCity: {city}\r\nIP: {ip}\r\nCreated:	{created}\r\nUser left:	{user_left}\r\nWaited:	{waited}\r\nChat duration:	{chat_duration}\r\n\r\nMessage:\r\n{message}\r\n\r\nURL of page from which user has send request:\r\n{url_request}\r\n\r\nClick to accept chat automatically\r\n{url_accept}\r\n\r\nSurvey\r\n{survey}\r\n\r\nSincerely,\r\nZTLawFirm.', 'New chat request', '', 0, '', 0, 'muralikumar.krishnamurthy@gmail.com'),
(5, 'Chat was closed', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\n{operator} has closed a chat\r\nName: {name}\r\nEmail: {email}\r\nPhone: {phone}\r\nDepartment: {department}\r\nCountry: {country}\r\nCity: {city}\r\nIP: {ip}\r\nCreated:	{created}\r\nUser left:	{user_left}\r\nWaited:	{waited}\r\nChat duration:	{chat_duration}\r\n\r\nMessage:\r\n{message}\r\n\r\nAdditional data, if any:\r\n{additional_data}\r\n\r\nURL of page from which user has send request:\r\n{url_request}\r\n\r\nSurvey:\r\n{survey}\r\n\r\nSincerely,\r\nZTLawFirm.', 'Chat was closed', '', 0, '', 0, 'muralikumar.krishnamurthy@gmail.com'),
(6, 'New FAQ question', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nNew FAQ question\r\nEmail: {email}\r\n\r\nQuestion:\r\n{question}\r\n\r\nQuestion URL:\r\n{url_question}\r\n\r\nURL to answer a question:\r\n{url_request}\r\n\r\nSincerely,\r\nLive Support Team', 'New FAQ question', '', 0, '', 0, 'muralikumar.krishnamurthy@gmail.com'),
(7, 'New unread message', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nUser request data:\r\nName: {name}\r\nEmail: {email}\r\nPhone: {phone}\r\nDepartment: {department}\r\nCountry: {country}\r\nCity: {city}\r\nIP: {ip}\r\nCreated:	{created}\r\nUser left:	{user_left}\r\nWaited:	{waited}\r\nChat duration:	{chat_duration}\r\n\r\nMessage:\r\n{message}\r\n\r\nURL of page from which user has send request:\r\n{url_request}\r\n\r\nClick to accept chat automatically\r\n{url_accept}\r\n\r\nSurvey:\r\n{survey}\r\n\r\nSincerely,\r\nZTLawFirm.', 'New unread message', '', 0, '', 0, 'muralikumar.krishnamurthy@gmail.com'),
(8, 'Filled form', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nUser has filled a form\r\nForm name - {form_name}\r\nUser IP - {ip}\r\nDownload filled data - {url_download}\r\nView filled data - {url_view}\r\n\r\n{content}\r\n\r\nSincerely,\r\nLive Support Team', 'Filled form - {form_name}', '', 0, '', 0, 'muralikumar.krishnamurthy@gmail.com'),
(9, 'Chat was accepted', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nOperator {user_name} has accepted a chat [{chat_id}]\r\n\r\nUser request data:\r\nName: {name}\r\nEmail: {email}\r\nPhone: {phone}\r\nDepartment: {department}\r\nCountry: {country}\r\nCity: {city}\r\nIP: {ip}\r\nCreated:	{created}\r\nUser left:	{user_left}\r\nWaited:	{waited}\r\nChat duration:	{chat_duration}\r\n\r\nMessage:\r\n{message}\r\n\r\nURL of page from which user has send request:\r\n{url_request}\r\n\r\nClick to accept chat automatically\r\n{url_accept}\r\n\r\nSurvey:\r\n{survey}\r\n\r\nSincerely,\r\nZTLawFirm.', 'Chat was accepted [{chat_id}]', '', 0, '', 0, 'muralikumar.krishnamurthy@gmail.com'),
(10, 'Permission request', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nOperator {user} has requested these permissions\r\n\r\n{permissions}\r\n\r\nSincerely,\r\nZTLawFirm.', 'Permission request from {user}', '', 0, '', 0, ''),
(11, 'You have unread messages', 'ZTLawFirm', 0, '', 0, 0, 'Hello,\r\n\r\nOperator {operator} has answered to you\r\n\r\n{messages}\r\n\r\nSincerely,\r\nZTLawFirm.', 'Operator has answered to your request', '', 0, '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_form`
--

CREATE TABLE `lh_abstract_form` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  `name_attr` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intro_attr` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xls_columns` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pagelayout` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_content` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_form_collected`
--

CREATE TABLE `lh_abstract_form_collected` (
  `id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  `ip` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_proactive_chat_event`
--

CREATE TABLE `lh_abstract_proactive_chat_event` (
  `id` int(11) NOT NULL,
  `vid_id` int(11) NOT NULL,
  `ev_id` int(11) NOT NULL,
  `ts` int(11) NOT NULL,
  `val` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_proactive_chat_invitation`
--

CREATE TABLE `lh_abstract_proactive_chat_invitation` (
  `id` int(11) NOT NULL,
  `siteaccess` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_on_site` int(11) NOT NULL,
  `pageviews` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_returning` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_times` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `hide_after_ntimes` int(11) NOT NULL,
  `show_on_mobile` int(11) NOT NULL,
  `delay` int(11) NOT NULL,
  `delay_init` int(11) NOT NULL,
  `show_instant` int(11) NOT NULL,
  `autoresponder_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_ids` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_returning_nick` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referrer` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_random_operator` int(11) NOT NULL,
  `operator_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  `event_invitation` int(11) NOT NULL,
  `dynamic_invitation` int(11) NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requires_email` int(11) NOT NULL,
  `iddle_for` int(11) NOT NULL,
  `event_type` int(11) NOT NULL,
  `requires_username` int(11) NOT NULL,
  `requires_phone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_proactive_chat_invitation_event`
--

CREATE TABLE `lh_abstract_proactive_chat_invitation_event` (
  `id` int(11) NOT NULL,
  `invitation_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `min_number` int(11) NOT NULL,
  `during_seconds` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_proactive_chat_variables`
--

CREATE TABLE `lh_abstract_proactive_chat_variables` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_timeout` int(11) NOT NULL,
  `filter_val` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_product`
--

CREATE TABLE `lh_abstract_product` (
  `id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disabled` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `departament_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_product_departament`
--

CREATE TABLE `lh_abstract_product_departament` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `departament_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_rest_api_key`
--

CREATE TABLE `lh_abstract_rest_api_key` (
  `id` int(11) NOT NULL,
  `api_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_subject`
--

CREATE TABLE `lh_abstract_subject` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_subject_chat`
--

CREATE TABLE `lh_abstract_subject_chat` (
  `id` bigint(20) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `chat_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_subject_dep`
--

CREATE TABLE `lh_abstract_subject_dep` (
  `id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_survey`
--

CREATE TABLE `lh_abstract_survey` (
  `id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feedback_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_stars_1_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_stars_1_pos` int(11) NOT NULL,
  `max_stars_2_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_stars_2_pos` int(11) NOT NULL,
  `max_stars_2` int(11) NOT NULL,
  `max_stars_3_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_stars_3_pos` int(11) NOT NULL,
  `max_stars_3` int(11) NOT NULL,
  `max_stars_4_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_stars_4_pos` int(11) NOT NULL,
  `max_stars_4` int(11) NOT NULL,
  `max_stars_5_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_stars_5_pos` int(11) NOT NULL,
  `max_stars_5` int(11) NOT NULL,
  `question_options_1` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_1_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_1_pos` int(11) NOT NULL,
  `question_options_2` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_2_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_2_pos` int(11) NOT NULL,
  `question_options_3` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_3_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_3_pos` int(11) NOT NULL,
  `question_options_4` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_4_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_4_pos` int(11) NOT NULL,
  `question_options_5` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_5_items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_options_5_pos` int(11) NOT NULL,
  `question_plain_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_1_pos` int(11) NOT NULL,
  `question_plain_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_2_pos` int(11) NOT NULL,
  `question_plain_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_3_pos` int(11) NOT NULL,
  `question_plain_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_4_pos` int(11) NOT NULL,
  `question_plain_5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_5_pos` int(11) NOT NULL,
  `max_stars_1_enabled` int(11) NOT NULL,
  `max_stars_2_enabled` int(11) NOT NULL,
  `max_stars_3_enabled` int(11) NOT NULL,
  `max_stars_4_enabled` int(11) NOT NULL,
  `max_stars_5_enabled` int(11) NOT NULL,
  `question_options_1_enabled` int(11) NOT NULL,
  `question_options_2_enabled` int(11) NOT NULL,
  `question_options_3_enabled` int(11) NOT NULL,
  `question_options_4_enabled` int(11) NOT NULL,
  `question_options_5_enabled` int(11) NOT NULL,
  `question_plain_1_enabled` int(11) NOT NULL,
  `question_plain_2_enabled` int(11) NOT NULL,
  `question_plain_3_enabled` int(11) NOT NULL,
  `question_plain_4_enabled` int(11) NOT NULL,
  `question_plain_5_enabled` int(11) NOT NULL,
  `max_stars_1` int(11) NOT NULL,
  `max_stars_1_req` int(11) NOT NULL,
  `max_stars_2_req` int(11) NOT NULL,
  `max_stars_3_req` int(11) NOT NULL,
  `max_stars_4_req` int(11) NOT NULL,
  `max_stars_5_req` int(11) NOT NULL,
  `question_options_1_req` int(11) NOT NULL,
  `question_options_2_req` int(11) NOT NULL,
  `question_options_3_req` int(11) NOT NULL,
  `question_options_4_req` int(11) NOT NULL,
  `question_options_5_req` int(11) NOT NULL,
  `question_plain_1_req` int(11) NOT NULL,
  `question_plain_2_req` int(11) NOT NULL,
  `question_plain_3_req` int(11) NOT NULL,
  `question_plain_4_req` int(11) NOT NULL,
  `question_plain_5_req` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_survey_item`
--

CREATE TABLE `lh_abstract_survey_item` (
  `id` bigint(20) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ftime` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `max_stars_1` int(11) NOT NULL,
  `max_stars_2` int(11) NOT NULL,
  `max_stars_3` int(11) NOT NULL,
  `max_stars_4` int(11) NOT NULL,
  `max_stars_5` int(11) NOT NULL,
  `question_options_1` int(11) NOT NULL,
  `question_options_2` int(11) NOT NULL,
  `question_options_3` int(11) NOT NULL,
  `question_options_4` int(11) NOT NULL,
  `question_options_5` int(11) NOT NULL,
  `question_plain_1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_plain_5` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_abstract_widget_theme`
--

CREATE TABLE `lh_abstract_widget_theme` (
  `id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_company` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `onl_bcolor` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bor_bcolor` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'e3e3e3',
  `text_color` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `online_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `online_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `offline_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `offline_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bot_status_text` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_background` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_tcolor` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_bcolor` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_border` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_close_bg` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_hover_bg` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_close_hover_bg` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_status_css` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_container_css` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_widget_css` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_popup_css` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_header` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `need_help_text` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `online_text` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `offline_text` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `widget_border_color` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `copyright_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `copyright_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `widget_copyright_url` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_copyright` int(11) NOT NULL DEFAULT '1',
  `explain_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `intro_operator_text` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimize_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimize_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restore_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restore_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `close_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `popup_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `popup_image_path` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `support_joined` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `support_closed` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pending_join` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noonline_operators` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noonline_operators_offline` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hide_close` int(11) NOT NULL,
  `show_need_help_delay` int(11) NOT NULL DEFAULT '0',
  `show_status_delay` int(11) NOT NULL DEFAULT '0',
  `modern_look` tinyint(1) NOT NULL DEFAULT '0',
  `hide_popup` int(11) NOT NULL,
  `show_need_help` int(11) NOT NULL DEFAULT '1',
  `show_need_help_timeout` int(11) NOT NULL DEFAULT '24',
  `header_height` int(11) NOT NULL,
  `header_padding` int(11) NOT NULL,
  `widget_border_width` int(11) NOT NULL,
  `hide_ts` int(11) NOT NULL,
  `widget_response_width` int(11) NOT NULL,
  `show_voting` tinyint(1) NOT NULL DEFAULT '1',
  `department_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_select` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buble_visitor_background` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buble_visitor_title_color` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buble_visitor_text_color` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buble_operator_background` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buble_operator_title_color` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `buble_operator_text_color` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_admin_theme`
--

CREATE TABLE `lh_admin_theme` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `static_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `static_js_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `static_css_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_css` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_canned_msg`
--

CREATE TABLE `lh_canned_msg` (
  `id` int(11) NOT NULL,
  `msg` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fallback_msg` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `explain` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `languages` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `delay` int(11) NOT NULL,
  `auto_send` tinyint(1) NOT NULL,
  `attr_int_1` int(11) NOT NULL,
  `attr_int_2` int(11) NOT NULL,
  `attr_int_3` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_canned_msg_tag`
--

CREATE TABLE `lh_canned_msg_tag` (
  `id` int(11) NOT NULL,
  `tag` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_canned_msg_tag_link`
--

CREATE TABLE `lh_canned_msg_tag_link` (
  `id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `canned_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat`
--

CREATE TABLE `lh_chat` (
  `id` int(11) NOT NULL,
  `nick` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `status_sub` int(11) NOT NULL DEFAULT '0',
  `status_sub_sub` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referrer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_referrer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_variables` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dep_id` int(11) NOT NULL,
  `sender_user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `pnd_time` int(11) NOT NULL DEFAULT '0',
  `cls_time` int(11) NOT NULL DEFAULT '0',
  `usaccept` int(11) NOT NULL DEFAULT '0',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `user_closed_ts` int(11) NOT NULL DEFAULT '0',
  `support_informed` int(11) NOT NULL DEFAULT '0',
  `unread_messages_informed` int(11) NOT NULL DEFAULT '0',
  `reinform_timeout` int(11) NOT NULL DEFAULT '0',
  `last_op_msg_time` int(11) NOT NULL DEFAULT '0',
  `has_unread_op_messages` int(11) NOT NULL DEFAULT '0',
  `unread_op_messages_informed` int(11) NOT NULL DEFAULT '0',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unanswered_chat` int(11) NOT NULL,
  `anonymized` tinyint(1) NOT NULL,
  `user_typing` int(11) NOT NULL,
  `user_typing_txt` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_typing` int(11) NOT NULL,
  `operator_typing_id` int(11) NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `has_unread_messages` int(11) NOT NULL,
  `last_user_msg_time` int(11) NOT NULL,
  `fbst` tinyint(1) NOT NULL,
  `online_user_id` int(11) NOT NULL,
  `auto_responder_id` int(11) NOT NULL,
  `last_msg_id` int(11) NOT NULL,
  `lsync` int(11) NOT NULL,
  `transfer_uid` int(11) NOT NULL,
  `additional_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_tz_identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lon` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_admin` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_sub_arg` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uagent` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_locale` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_locale_to` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_send` int(11) NOT NULL,
  `screenshot_id` int(11) NOT NULL,
  `wait_time` int(11) NOT NULL,
  `chat_duration` int(11) NOT NULL,
  `tslasign` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `chat_initiator` int(11) NOT NULL,
  `transfer_timeout_ts` int(11) NOT NULL,
  `transfer_timeout_ac` int(11) NOT NULL,
  `transfer_if_na` int(11) NOT NULL,
  `na_cb_executed` int(11) NOT NULL,
  `device_type` int(11) NOT NULL,
  `nc_cb_executed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_chat`
--

INSERT INTO `lh_chat` (`id`, `nick`, `status`, `status_sub`, `status_sub_sub`, `time`, `user_id`, `hash`, `referrer`, `session_referrer`, `chat_variables`, `remarks`, `ip`, `dep_id`, `sender_user_id`, `product_id`, `pnd_time`, `cls_time`, `usaccept`, `user_status`, `user_closed_ts`, `support_informed`, `unread_messages_informed`, `reinform_timeout`, `last_op_msg_time`, `has_unread_op_messages`, `unread_op_messages_informed`, `email`, `country_code`, `country_name`, `unanswered_chat`, `anonymized`, `user_typing`, `user_typing_txt`, `operator_typing`, `operator_typing_id`, `phone`, `has_unread_messages`, `last_user_msg_time`, `fbst`, `online_user_id`, `auto_responder_id`, `last_msg_id`, `lsync`, `transfer_uid`, `additional_data`, `user_tz_identifier`, `lat`, `lon`, `city`, `operation`, `operation_admin`, `status_sub_arg`, `uagent`, `chat_locale`, `chat_locale_to`, `mail_send`, `screenshot_id`, `wait_time`, `chat_duration`, `tslasign`, `priority`, `chat_initiator`, `transfer_timeout_ts`, `transfer_timeout_ac`, `transfer_if_na`, `na_cb_executed`, `device_type`, `nc_cb_executed`) VALUES
(1, 'User', 1, 0, 0, 1526283666, 1, '7ccb72dfcf7ae02c6d39655d471ea443b28a1bb5', '', '', '', '', '::1', 1, 0, 0, 1526283666, 0, 0, 1, 1526284077, 1, 0, 0, 1526283687, 0, 0, '', '', '', 0, 0, 1526284072, 'Visitor has left the chat!', 0, 0, '', 0, 0, 0, 0, 0, 3, 1526284073, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(2, 'User2', 1, 0, 0, 1526284104, 1, 'a67bf7d40500d3a33839332bbd9549505c81b53e', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526284104, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, '', '', '', 0, 0, 0, '', 0, 0, '', 0, 0, 0, 0, 0, 4, 1526285560, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0', 'en-US', '', 0, 0, 122, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(3, 'User1', 1, 0, 0, 1526284114, 1, 'be56340e1932f437c0fd7059bc81db21f5e27651', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526284114, 0, 0, 1, 1526285121, 1, 0, 0, 1526284250, 0, 0, '', '', '', 0, 0, 1526285116, 'Visitor has left the chat!', 0, 0, '', 0, 1526284270, 0, 0, 0, 10, 1526285076, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 130, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(4, 'User1', 1, 3, 0, 1526286206, 1, '869ab0e86c23153eb80b938208c1b13d042e99bc', '', '', '', '', '::1', 1, 0, 0, 1526286206, 0, 0, 1, 1526290212, 1, 0, 0, 1526286265, 0, 0, '', '', '', 0, 0, 1526290207, 'Visitor has left the chat!', 0, 0, '', 0, 1526290212, 0, 0, 0, 27, 1526290192, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(5, 'lalithsagar', 1, 0, 0, 1526286446, 1, '1fe16cdf3af6e0403ee6cc557f3a12fde9153d27', '', '', '', '', '192.168.0.119', 1, 0, 0, 1526286446, 0, 0, 2, 1526287023, 1, 0, 0, 1526298963, 1, 0, '', '', '', 0, 0, 1526287018, 'Visitor has left the chat!', 0, 0, '', 0, 1526286875, 1, 0, 0, 54, 1526287007, 0, '', '', '0', '0', '', 'lhc_screenshot\n', '', '', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-GB', '', 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(7, 'adssad', 2, 0, 0, 1526294217, 1, '6c92264e4fdf97269338c9851e21e564b568e07b', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526294217, 1526296935, 0, 1, 1526295573, 1, 0, 0, 1526294319, 0, 0, '', '', '', 0, 0, 1526295568, 'Visitor has left the chat!', 0, 0, '', 0, 1526296935, 0, 0, 0, 32, 1526295546, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 80, 102, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(10, 'sdfsdf', 1, 0, 0, 1526296406, 1, 'e952630c6264b9898b96992dfc88295d11224801', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526296406, 0, 0, 1, 1526296593, 1, 0, 0, 0, 0, 0, '', '', '', 1, 0, 1526296588, 'Visitor has left the chat!', 0, 0, '', 0, 0, 0, 0, 0, 35, 1526296593, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 381, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(11, 'sfsdfsdfsdf', 1, 2, 0, 1526296612, 1, 'dce8feb60c42cf5ca6eeebeddbf319fab771ec5a', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526296612, 0, 0, 1, 1526296667, 1, 0, 0, 0, 0, 0, '', '', '', 1, 0, 1526296662, 'Visitor has left the chat!', 0, 0, '', 0, 1526296784, 0, 0, 0, 40, 1526296666, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(12, 'sdfsdfsd', 1, 2, 0, 1526296681, 1, '024af5e04777eafb43ea3a374806b8466d640975', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526296681, 0, 0, 1, 1526296782, 1, 0, 0, 0, 0, 0, '', '', '', 1, 0, 1526296777, 'Visitor has left the chat!', 0, 0, '', 0, 1526296779, 0, 0, 0, 38, 1526296750, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(13, 'Murali', 1, 3, 0, 1526296860, 1, 'f38b730fa30e10e89afd003c6b1063fc7a269c2a', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526296860, 0, 0, 1, 1526297475, 1, 0, 0, 1526297109, 0, 0, '', '', '', 0, 0, 1526297470, 'Visitor has left the chat!', 0, 0, '', 0, 1526297464, 2, 0, 0, 51, 1526297465, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(15, 'UserTwo', 1, 2, 0, 1526297275, 1, '6246137f272d4fb861eebeedfc14fafdd3c396c8', '', '', '', '', '192.168.0.118', 1, 0, 0, 1526297275, 0, 0, 1, 1526297287, 1, 0, 0, 0, 0, 0, '', '', '', 1, 0, 1526297282, 'Visitor has left the chat!', 0, 0, '', 0, 1526297285, 0, 0, 0, 49, 1526297282, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(16, 'lalithsagar', 1, 0, 0, 1526299035, 1, '17990a60fe77d4ba3aff8cf0f74cdc817a36ec23', '', '', '', '', '192.168.0.119', 1, 0, 0, 1526299035, 0, 0, 2, 1526299120, 1, 0, 0, 1526300146, 1, 0, '', '', '', 0, 0, 1526299115, 'Visitor has left the chat!', 0, 0, '', 0, 0, 0, 0, 0, 58, 1526299119, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-GB', '', 0, 0, 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(17, 'Manager', 3, 0, 0, 1526300270, 1, '63f925fe98565225652aa1e566b33b55f85247b2', '//192.168.0.118:8080/zcodialawfirm/', '', '', '', '192.168.0.118', 1, 0, 0, 1526300270, 0, 0, 0, 0, 1, 0, 0, 1526300327, 1, 0, '', '', '', 0, 0, 0, '', 0, 0, '', 0, 1526300294, 0, 0, 0, 60, 0, 0, '', '', '0', '0', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(18, 'Murali', 1, 0, 0, 1526300652, 1, '8a2602dd786b45ee9bf54d5b75c451f967577527', '//192.168.0.118:8080/zcodialawfirm/', '', '', '', '192.168.0.118', 1, 0, 0, 1526300652, 0, 0, 2, 1526300748, 1, 0, 0, 1526304006, 1, 0, '', '', '', 1, 0, 1526300743, 'Visitor has left the chat!', 0, 0, '', 0, 0, 0, 1, 0, 74, 1526300720, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 3352, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(19, 'Murali', 1, 0, 0, 1526302491, 1, '4671ec722ed833168ce9545b0c8c424cb4a06f5c', '//192.168.0.118:8080/zcodialawfirm/', '', '', '', '192.168.0.118', 1, 0, 0, 1526302491, 0, 0, 1, 1526302885, 1, 0, 0, 1526302548, 0, 0, '', '', '', 0, 0, 1526302880, 'Visitor has left the chat!', 0, 0, '', 0, 1526302537, 1, 12, 0, 66, 1526302873, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(20, 'Murali', 1, 0, 0, 1526303771, 1, '6b8fd66e73681d752002064a5ae12dba41343bbb', '//192.168.0.118:8080/zcodialawfirm/', '', '', '', '192.168.0.118', 1, 0, 0, 1526303771, 0, 0, 1, 1526303970, 1, 0, 0, 1526303784, 0, 0, '', '', '', 0, 0, 1526303965, 'Visitor has left the chat!', 0, 0, '', 0, 0, 0, 21, 0, 69, 1526303953, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(21, 'Murali', 1, 0, 0, 1526303991, 1, '1bac1fdc571050f258b628031323be986f9bbc4b', '//192.168.0.118:8080/zcodialawfirm/', '', '', '', '192.168.0.118', 1, 0, 0, 1526303991, 0, 0, 0, 0, 1, 0, 0, 1526304003, 0, 0, '', '', '', 0, 0, 0, '', 0, 0, '', 0, 0, 0, 22, 0, 72, 1526304934, 0, '', '', '0', '0', '', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', 'en-US', '', 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lh_chatbox`
--

CREATE TABLE `lh_chatbox` (
  `id` int(11) NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_id` int(11) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_chatbox`
--

INSERT INTO `lh_chatbox` (`id`, `identifier`, `name`, `chat_id`, `active`) VALUES
(1, 'default', 'Chatbox', 17, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_accept`
--

CREATE TABLE `lh_chat_accept` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ctime` int(11) NOT NULL,
  `wused` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_archive_range`
--

CREATE TABLE `lh_chat_archive_range` (
  `id` int(11) NOT NULL,
  `range_from` int(11) NOT NULL,
  `range_to` int(11) NOT NULL,
  `year_month` int(11) NOT NULL,
  `older_than` int(11) NOT NULL,
  `last_id` int(11) NOT NULL,
  `first_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_blocked_user`
--

CREATE TABLE `lh_chat_blocked_user` (
  `id` int(11) NOT NULL,
  `ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `datets` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_config`
--

CREATE TABLE `lh_chat_config` (
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `explain` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hidden` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_chat_config`
--

INSERT INTO `lh_chat_config` (`identifier`, `value`, `type`, `explain`, `hidden`) VALUES
('accept_chat_link_timeout', '300', 0, 'How many seconds chat accept link is valid. Set 0 to force login all the time manually.', 0),
('accept_tos_link', '#', 0, 'Change to your site Terms of Service', 0),
('activity_timeout', '5', 0, 'How long operator should go offline automatically because of inactivity. Value in minutes', 0),
('activity_track_all', '0', 0, 'Track all logged operators activity and ignore their individual settings.', 0),
('allow_reopen_closed', '1', 0, 'Allow user to reopen closed chats?', 0),
('application_name', 'a:31:{s:3:\"eng\";s:31:\"Live Helper Chat - live support\";s:3:\"lit\";s:26:\"Live Helper Chat - pagalba\";s:3:\"hrv\";s:0:\"\";s:3:\"esp\";s:0:\"\";s:3:\"por\";s:0:\"\";s:3:\"nld\";s:0:\"\";s:3:\"ara\";s:0:\"\";s:3:\"ger\";s:0:\"\";s:3:\"pol\";s:0:\"\";s:3:\"rus\";s:0:\"\";s:3:\"ita\";s:0:\"\";s:3:\"fre\";s:0:\"\";s:3:\"chn\";s:0:\"\";s:3:\"cse\";s:0:\"\";s:3:\"nor\";s:0:\"\";s:3:\"tur\";s:0:\"\";s:3:\"vnm\";s:0:\"\";s:3:\"idn\";s:0:\"\";s:3:\"sve\";s:0:\"\";s:3:\"per\";s:0:\"\";s:3:\"ell\";s:0:\"\";s:3:\"dnk\";s:0:\"\";s:3:\"rou\";s:0:\"\";s:3:\"bgr\";s:0:\"\";s:3:\"tha\";s:0:\"\";s:3:\"geo\";s:0:\"\";s:3:\"fin\";s:0:\"\";s:3:\"alb\";s:0:\"\";s:3:\"heb\";s:0:\"\";s:3:\"cat\";s:0:\"\";s:10:\"site_admin\";s:31:\"Live Helper Chat - live support\";}', 1, 'Support application name, visible in browser title.', 0),
('assign_workflow_timeout', '0', 0, 'Chats waiting in pending line more than n seconds should be auto assigned first. Time in seconds', 0),
('autoclose_timeout', '0', 0, 'Automatic chats closing. 0 - disabled, n > 0 time in minutes before chat is automatically closed', 0),
('autologin_data', 'a:3:{i:0;b:0;s:11:\"secret_hash\";s:16:\"please_change_me\";s:7:\"enabled\";i:0;}', 0, 'Autologin configuration data', 1),
('automatically_reopen_chat', '1', 0, 'Automatically reopen chat on widget open', 0),
('autopurge_timeout', '0', 0, 'Automatic chats purging. 0 - disabled, n > 0 time in minutes before chat is automatically deleted', 0),
('banned_ip_range', '', 0, 'Which ip should not be allowed to chat', 0),
('bbc_button_visible', '1', 0, 'Show BB Code button', 0),
('cduration_timeout_operator', '10', 0, 'How long visitor can wait for message from operator before time between messages are ignored. Values in minutes.', 0),
('cduration_timeout_user', '4', 0, 'How long operator can wait for message from visitor before time between messages are ignored. Values in minutes.', 0),
('chatbox_data', 'a:6:{i:0;b:0;s:20:\"chatbox_auto_enabled\";i:0;s:19:\"chatbox_secret_hash\";s:9:\"94516b988\";s:20:\"chatbox_default_name\";s:7:\"Chatbox\";s:17:\"chatbox_msg_limit\";i:50;s:22:\"chatbox_default_opname\";s:7:\"Manager\";}', 0, 'Chatbox configuration', 1),
('checkstatus_timeout', '0', 0, 'Interval between chat status checks in seconds, 0 disabled.', 0),
('cleanup_cronjob', '0', 0, 'Cleanup should be done only using cronjob.', 0),
('customer_company_name', 'ZTLawFirm', 0, 'Your company name - visible in bottom left corner', 0),
('customer_site_url', 'http://ztlawfirm.com', 0, 'Your site URL address', 0),
('dashboard_order', '[[\"online_operators\",\"departments_stats\",\"online_visitors\"],[\"pending_chats\",\"unread_chats\",\"transfered_chats\"],[\"active_chats\",\"closed_chats\"]]', 0, 'Home page dashboard widgets order', 0),
('default_admin_theme_id', '0', 0, 'Default admin theme ID', 1),
('default_theme_id', '0', 0, 'Default theme ID.', 1),
('disable_html5_storage', '1', 0, 'Disable HMTL5 storage, check it if your site is switching between http and https', 0),
('disable_iframe_sharing', '1', 0, 'Disable iframes in sharing mode', 0),
('disable_js_execution', '1', 0, 'Disable JS execution in Co-Browsing operator window', 0),
('disable_popup_restore', '0', 0, 'Disable option in widget to open new window. Restore icon will be hidden', 0),
('disable_print', '0', 0, 'Disable chat print', 0),
('disable_send', '0', 0, 'Disable chat transcript send', 0),
('do_no_track_ip', '0', 0, 'Do not track visitors IP', 0),
('encrypt_msg_after', '0', 0, 'After how many days anonymize messages', 0),
('encrypt_msg_op', '0', 0, 'Anonymize also operators messages', 0),
('explicit_http_mode', '', 0, 'Please enter explicit http mode. Either http: or https:, do not forget : at the end.', 0),
('export_hash', '7c7cdf5ff', 0, 'Chats export secret hash', 0),
('faq_email_required', '0', 0, 'Is visitor e-mail required for FAQ', 0),
('file_configuration', 'a:7:{i:0;b:0;s:5:\"ft_op\";s:43:\"gif|jpe?g|png|zip|rar|xls|doc|docx|xlsx|pdf\";s:5:\"ft_us\";s:26:\"gif|jpe?g|png|doc|docx|pdf\";s:6:\"fs_max\";i:2048;s:18:\"active_user_upload\";b:0;s:16:\"active_op_upload\";b:1;s:19:\"active_admin_upload\";b:1;}', 0, 'Files configuration item', 1),
('front_tabs', 'dashboard,online_users,online_map', 0, 'Home page tabs order', 0),
('geo_data', 'a:5:{i:0;b:0;s:21:\"geo_detection_enabled\";i:1;s:22:\"geo_service_identifier\";s:8:\"max_mind\";s:23:\"max_mind_detection_type\";s:7:\"country\";s:22:\"max_mind_city_location\";s:37:\"var/external/geoip/GeoLite2-City.mmdb\";}', 0, '', 1),
('geo_location_data', 'a:3:{s:4:\"zoom\";i:4;s:3:\"lat\";s:7:\"49.8211\";s:3:\"lng\";s:7:\"11.7835\";}', 0, '', 1),
('geoadjustment_data', 'a:8:{i:0;b:0;s:18:\"use_geo_adjustment\";b:0;s:13:\"available_for\";s:0:\"\";s:15:\"other_countries\";s:6:\"custom\";s:8:\"hide_for\";s:0:\"\";s:12:\"other_status\";s:7:\"offline\";s:11:\"rest_status\";s:6:\"hidden\";s:12:\"apply_widget\";i:0;}', 0, 'Geo adjustment settings', 1),
('hide_button_dropdown', '1', 0, 'Hide close button in dropdown', 0),
('hide_disabled_department', '1', 0, 'Hide disabled department widget', 0),
('hide_right_column_frontpage', '0', 0, 'Hide right column in frontpage', 0),
('ignorable_ip', '', 0, 'Which ip should be ignored in online users list, separate by comma', 0),
('ignore_user_status', '0', 0, 'Ignore users online statuses and use departments online hours', 0),
('inform_unread_message', '0', 0, 'Inform visitor about unread messages from operator, value in minutes. 0 - disabled', 0),
('list_online_operators', '0', 0, 'List online operators.', 0),
('max_message_length', '500', 0, 'Maximum message length in characters', 0),
('message_seen_timeout', '24', 0, 'Proactive message timeout in hours. After how many hours proactive chat mesasge should be shown again.', 0),
('mheight', '', 0, 'Messages box height', 0),
('min_phone_length', '8', 0, 'Minimum phone number length', 0),
('need_help_tip', '1', 0, 'Show need help tooltip?', 0),
('need_help_tip_timeout', '24', 0, 'Need help tooltip timeout, after how many hours show again tooltip?', 0),
('on_close_exit_chat', '1', 0, 'On chat close exit chat', 0),
('online_if', '0', 0, '', 0),
('paidchat_data', '', 0, 'Paid chat configuration', 1),
('pro_active_invite', '1', 0, 'Is pro active chat invitation active. Online users tracking also has to be enabled', 0),
('pro_active_limitation', '-1', 0, 'Pro active chats invitations limitation based on pending chats, (-1) do not limit, (0,1,n+1) number of pending chats can be for invitation to be shown.', 0),
('pro_active_show_if_offline', '0', 0, 'Should invitation logic be executed if there is no online operators', 0),
('product_enabled_module', '0', 0, 'Product module is enabled', 1),
('product_show_departament', '0', 0, 'Enable products show by departments', 1),
('reopen_as_new', '1', 0, 'Reopen closed chat as new? Otherwise it will be reopened as active.', 0),
('reopen_chat_enabled', '1', 0, 'Reopen chat functionality enabled', 0),
('run_departments_workflow', '0', 0, 'Should cronjob run departments transfer workflow, even if user leaves a chat', 0),
('run_unaswered_chat_workflow', '0', 0, 'Should cronjob run unanswered chats workflow and execute unaswered chats callback, 0 - no, any other number bigger than 0 is a minits how long chat have to be not accepted before executing callback.', 0),
('session_captcha', '0', 0, 'Use session captcha. LHC have to be installed on the same domain or subdomain.', 0),
('sharing_auto_allow', '0', 0, 'Do not ask permission for users to see their screen', 0),
('sharing_nodejs_enabled', '0', 0, 'NodeJs support enabled', 0),
('sharing_nodejs_path', '', 0, 'socket.io path, optional', 0),
('sharing_nodejs_secure', '0', 0, 'Connect to NodeJs in https mode', 0),
('sharing_nodejs_sllocation', 'https://cdn.socket.io/socket.io-1.1.0.js', 0, 'Location of SocketIO JS library', 0),
('sharing_nodejs_socket_host', '', 0, 'Host where NodeJs is running', 0),
('show_language_switcher', '0', 0, 'Show users option to switch language at widget', 0),
('show_languages', 'eng,lit,hrv,esp,por,nld,ara,ger,pol,rus,ita,fre,chn,cse,nor,tur,vnm,idn,sve,per,ell,dnk,rou,bgr,tha,geo,fin,alb', 0, 'Between what languages user should be able to switch', 0),
('smtp_data', 'a:5:{s:4:\"host\";s:0:\"\";s:4:\"port\";s:2:\"25\";s:8:\"use_smtp\";i:0;s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";}', 0, 'SMTP configuration', 1),
('sound_invitation', '1', 0, 'Play sound on invitation to chat.', 0),
('speech_data', 'a:3:{i:0;b:0;s:8:\"language\";i:7;s:7:\"dialect\";s:5:\"en-US\";}', 1, '', 1),
('start_chat_data', 'a:23:{i:0;b:0;s:21:\"name_visible_in_popup\";b:1;s:27:\"name_visible_in_page_widget\";b:1;s:19:\"name_require_option\";s:8:\"required\";s:22:\"email_visible_in_popup\";b:0;s:28:\"email_visible_in_page_widget\";b:0;s:20:\"email_require_option\";s:8:\"required\";s:24:\"message_visible_in_popup\";b:1;s:30:\"message_visible_in_page_widget\";b:1;s:22:\"message_require_option\";s:8:\"required\";s:22:\"phone_visible_in_popup\";b:0;s:28:\"phone_visible_in_page_widget\";b:0;s:20:\"phone_require_option\";s:8:\"required\";s:21:\"force_leave_a_message\";b:0;s:29:\"offline_name_visible_in_popup\";b:1;s:35:\"offline_name_visible_in_page_widget\";b:1;s:27:\"offline_name_require_option\";s:8:\"required\";s:30:\"offline_phone_visible_in_popup\";b:0;s:36:\"offline_phone_visible_in_page_widget\";b:0;s:28:\"offline_phone_require_option\";s:8:\"required\";s:32:\"offline_message_visible_in_popup\";b:1;s:38:\"offline_message_visible_in_page_widget\";b:1;s:30:\"offline_message_require_option\";s:8:\"required\";}', 0, '', 1),
('suggest_leave_msg', '1', 0, 'Suggest user to leave a message then user chooses offline department', 0),
('sync_sound_settings', 'a:16:{i:0;b:0;s:12:\"repeat_sound\";i:1;s:18:\"repeat_sound_delay\";i:5;s:10:\"show_alert\";b:0;s:22:\"new_chat_sound_enabled\";b:1;s:31:\"new_message_sound_admin_enabled\";b:1;s:30:\"new_message_sound_user_enabled\";b:1;s:14:\"online_timeout\";d:300;s:22:\"check_for_operator_msg\";d:10;s:21:\"back_office_sinterval\";d:10;s:22:\"chat_message_sinterval\";d:3.5;s:20:\"long_polling_enabled\";b:0;s:30:\"polling_chat_message_sinterval\";d:1.5;s:29:\"polling_back_office_sinterval\";d:5;s:18:\"connection_timeout\";i:30;s:28:\"browser_notification_message\";b:0;}', 0, '', 1),
('track_activity', '0', 0, 'Track users activity on site?', 0),
('track_domain', '', 0, 'Set your domain to enable user tracking across different domain subdomains.', 0),
('track_footprint', '0', 0, 'Track users footprint. For this also online visitors tracking should be enabled', 0),
('track_if_offline', '0', 0, 'Track online visitors even if there is no online operators', 0),
('track_is_online', '0', 0, 'Track is user still on site, chat status checks also has to be enabled', 0),
('track_mouse_activity', '0', 0, 'Should mouse movement be tracked as activity measure, if not checked only basic events would be tracked', 0),
('track_online_visitors', '1', 0, 'Enable online site visitors tracking', 0),
('tracked_footprint_cleanup', '90', 0, 'How many days keep records of users footprint.', 0),
('tracked_users_cleanup', '160', 0, 'How many days keep records of online users.', 0),
('tracked_users_cleanup_last', '1526300630', 0, 'Track last cleanup', 1),
('transfer_configuration', '0', 0, 'Transfer configuration', 1),
('translation_data', 'a:6:{i:0;b:0;s:19:\"translation_handler\";s:4:\"bing\";s:19:\"enable_translations\";b:0;s:14:\"bing_client_id\";s:0:\"\";s:18:\"bing_client_secret\";s:0:\"\";s:14:\"google_api_key\";s:0:\"\";}', 0, 'Translation data', 1),
('update_ip', '127.0.0.1', 0, 'Which ip should be allowed to update DB by executing http request, separate by comma?', 0),
('use_secure_cookie', '0', 0, 'Use secure cookie, check this if you want to force SSL all the time', 0),
('voting_days_limit', '7', 0, 'How many days voting widget should not be expanded after last show', 0),
('xmp_data', 'a:14:{i:0;b:0;s:4:\"host\";s:15:\"talk.google.com\";s:6:\"server\";s:9:\"gmail.com\";s:8:\"resource\";s:6:\"xmpphp\";s:4:\"port\";s:4:\"5222\";s:7:\"use_xmp\";i:0;s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:11:\"xmp_message\";s:98:\"New chat request [{chat_id}] from [{department}]\r\n{messages}\r\nClick to accept a chat\r\n{url_accept}\";s:10:\"recipients\";s:0:\"\";s:20:\"xmp_accepted_message\";s:89:\"{user_name} has accepted a chat [{chat_id}] from [{department}]\r\n{messages}\r\n{url_accept}\";s:16:\"use_standard_xmp\";i:0;s:15:\"test_recipients\";s:0:\"\";s:21:\"test_group_recipients\";s:0:\"\";}', 0, 'XMP data', 1);

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_file`
--

CREATE TABLE `lh_chat_file` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upload_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_id` int(11) NOT NULL,
  `persistent` int(11) NOT NULL,
  `online_user_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_chat_file`
--

INSERT INTO `lh_chat_file` (`id`, `name`, `upload_name`, `size`, `type`, `file_path`, `extension`, `chat_id`, `persistent`, `online_user_id`, `user_id`, `date`) VALUES
(1, '7cccf47e3ee8119e5472d6efe907383b', 'beach-exotic-holiday-248797 (2).jpg', 20289, 'image/jpeg', 'var/storage/2018y/05/14/5/', 'jpg', 5, 0, 0, 1, 1526286875);

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_online_user`
--

CREATE TABLE `lh_chat_online_user` (
  `id` int(11) NOT NULL,
  `vid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_page` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referrer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_id` int(11) NOT NULL,
  `invitation_seen_count` int(11) NOT NULL,
  `invitation_id` int(11) NOT NULL,
  `last_visit` int(11) NOT NULL,
  `first_visit` int(11) NOT NULL,
  `total_visits` int(11) NOT NULL,
  `pages_count` int(11) NOT NULL,
  `tt_pages_count` int(11) NOT NULL,
  `invitation_count` int(11) NOT NULL,
  `last_check_time` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_country_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_country_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitor_tz` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_user_proactive` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator_user_id` int(11) NOT NULL,
  `message_seen` int(11) NOT NULL,
  `message_seen_ts` int(11) NOT NULL,
  `user_active` int(11) NOT NULL,
  `lat` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lon` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reopen_chat` int(11) NOT NULL,
  `time_on_site` int(11) NOT NULL,
  `tt_time_on_site` int(11) NOT NULL,
  `requires_email` int(11) NOT NULL,
  `requires_username` int(11) NOT NULL,
  `requires_phone` int(11) NOT NULL,
  `screenshot_id` int(11) NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `online_attr_system` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_chat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `online_attr` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_chat_online_user`
--

INSERT INTO `lh_chat_online_user` (`id`, `vid`, `ip`, `current_page`, `page_title`, `referrer`, `chat_id`, `invitation_seen_count`, `invitation_id`, `last_visit`, `first_visit`, `total_visits`, `pages_count`, `tt_pages_count`, `invitation_count`, `last_check_time`, `dep_id`, `user_agent`, `notes`, `user_country_code`, `user_country_name`, `visitor_tz`, `operator_message`, `operator_user_proactive`, `operator_user_id`, `message_seen`, `message_seen_ts`, `user_active`, `lat`, `lon`, `city`, `reopen_chat`, `time_on_site`, `tt_time_on_site`, `requires_email`, `requires_username`, `requires_phone`, `screenshot_id`, `identifier`, `operation`, `online_attr_system`, `operation_chat`, `online_attr`) VALUES
(1, '59715ffda04f39463048', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 18, 0, 0, 1526300630, 1526300630, 1, 1, 1, 0, 1526300630, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 1, 1526300652, 1, '0', '0', '', 1, 22, 22, 0, 0, 0, 0, '', '', '', '', ''),
(2, '07a3466d94de061c6244', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526300749, 1526300749, 1, 1, 1, 0, 1526300749, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(3, '84b562cc7bf45db1fd5a', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301065, 1526301065, 1, 1, 1, 0, 1526301065, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(4, 'd5ba1a7e4ad787f80f80', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301080, 1526301080, 1, 1, 1, 0, 1526301080, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(5, 'ddc98b6e88b6a129a152', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301240, 1526301240, 1, 1, 1, 0, 1526301240, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(6, '66e5490cc0d46f688fe8', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301312, 1526301312, 1, 1, 1, 0, 1526301312, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(7, '9fc10f7b10d8d4f08323', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301400, 1526301400, 1, 1, 1, 0, 1526301400, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(8, 'b8f833674b23071b5606', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301482, 1526301482, 1, 1, 1, 0, 1526301482, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(9, '9db5b69ecf6b9730f99b', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301543, 1526301543, 1, 1, 1, 0, 1526301543, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(10, 'd9ee055307cedbfb97b1', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526301635, 1526301635, 1, 1, 1, 0, 1526301635, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(11, '9effc6eb35a45b48f488', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526302076, 1526302076, 1, 1, 1, 0, 1526302076, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(12, 'ae25a993c45ac601b938', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 19, 0, 0, 1526302464, 1526302464, 1, 1, 1, 0, 1526302464, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 1, 1526302491, 1, '0', '0', '', 0, 27, 27, 0, 0, 0, 0, '', '', '', '', ''),
(13, '131c07874c2656e4990b', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526302886, 1526302886, 1, 1, 1, 0, 1526302886, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(14, 'f13fa890b5e4da2fb2b6', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526302891, 1526302891, 1, 1, 1, 0, 1526302891, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(15, '64a51e5b23dc02d6ec8e', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526302998, 1526302998, 1, 1, 1, 0, 1526302998, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(16, '1fa0ba920bb0951f6aae', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526303019, 1526303019, 1, 1, 1, 0, 1526303019, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(17, '9d0770ccabb2b65358b2', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526303126, 1526303126, 1, 1, 1, 0, 1526303126, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(18, '41c438834ac5d6cd8d78', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526303442, 1526303442, 1, 1, 1, 0, 1526303442, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(19, '08a8fca45ce6781e90c1', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526303522, 1526303522, 1, 1, 1, 0, 1526303522, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(20, '03ad91bd7475d5841198', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 0, 0, 0, 1526303587, 1526303587, 1, 1, 1, 0, 1526303587, 0, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 0, 0, 1, '0', '0', '', 0, 0, 0, 0, 0, 0, 0, '', '', '', '', ''),
(21, '5375e82c77152eafc72f', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 20, 0, 0, 1526303738, 1526303738, 1, 1, 1, 0, 1526303738, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 1, 1526303771, 1, '0', '0', '', 0, 33, 33, 0, 0, 0, 0, '', '', '', '', ''),
(22, '4e499eff456c419ed48f', '192.168.0.118', 'http://192.168.0.118:8080/zcodialawfirm/', '.:: ZcodiaLawFirm - Home Page ::.', '', 21, 0, 0, 1526303972, 1526303972, 1, 1, 1, 0, 1526303972, 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36', '', '', '', 'Asia/Yekaterinburg', '', '', 0, 1, 1526303991, 1, '0', '0', '', 0, 19, 19, 0, 0, 0, 0, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_online_user_footprint`
--

CREATE TABLE `lh_chat_online_user_footprint` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `online_user_id` int(11) NOT NULL,
  `page` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_paid`
--

CREATE TABLE `lh_chat_paid` (
  `id` int(11) NOT NULL,
  `hash` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_chat_start_settings`
--

CREATE TABLE `lh_chat_start_settings` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_cobrowse`
--

CREATE TABLE `lh_cobrowse` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `online_user_id` int(11) NOT NULL,
  `mtime` int(11) NOT NULL,
  `url` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `initialize` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `modifications` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `w` int(11) NOT NULL,
  `wh` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament`
--

CREATE TABLE `lh_departament` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xmpp_recipients` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `xmpp_group_recipients` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int(11) NOT NULL,
  `sort_priority` int(11) NOT NULL,
  `department_transfer_id` int(11) NOT NULL,
  `transfer_timeout` int(11) NOT NULL,
  `exclude_inactive_chats` int(11) NOT NULL,
  `delay_before_assign` int(11) NOT NULL,
  `max_ac_dep_chats` int(11) NOT NULL,
  `disabled` int(11) NOT NULL,
  `hidden` int(11) NOT NULL,
  `delay_lm` int(11) NOT NULL,
  `max_active_chats` int(11) NOT NULL,
  `max_timeout_seconds` int(11) NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mod_start_hour` int(4) NOT NULL,
  `mod_end_hour` int(4) NOT NULL,
  `tud_start_hour` int(4) NOT NULL,
  `tud_end_hour` int(4) NOT NULL,
  `wed_start_hour` int(4) NOT NULL,
  `wed_end_hour` int(4) NOT NULL,
  `thd_start_hour` int(4) NOT NULL,
  `thd_end_hour` int(4) NOT NULL,
  `frd_start_hour` int(4) NOT NULL,
  `frd_end_hour` int(4) NOT NULL,
  `sad_start_hour` int(4) NOT NULL,
  `sad_end_hour` int(4) NOT NULL,
  `sud_start_hour` int(4) NOT NULL,
  `sud_end_hour` int(4) NOT NULL,
  `nc_cb_execute` tinyint(1) NOT NULL,
  `na_cb_execute` tinyint(1) NOT NULL,
  `inform_unread` tinyint(1) NOT NULL,
  `active_balancing` tinyint(1) NOT NULL,
  `visible_if_online` tinyint(1) NOT NULL,
  `inform_close` int(11) NOT NULL,
  `inform_unread_delay` int(11) NOT NULL,
  `inform_options` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `online_hours_active` tinyint(1) NOT NULL,
  `inform_delay` int(11) NOT NULL,
  `attr_int_1` int(11) NOT NULL,
  `attr_int_2` int(11) NOT NULL,
  `attr_int_3` int(11) NOT NULL,
  `pending_max` int(11) NOT NULL,
  `pending_group_max` int(11) NOT NULL,
  `active_chats_counter` int(11) NOT NULL,
  `pending_chats_counter` int(11) NOT NULL,
  `closed_chats_counter` int(11) NOT NULL,
  `inform_close_all` int(11) NOT NULL,
  `inform_close_all_email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_configuration` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bot_configuration` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_departament`
--

INSERT INTO `lh_departament` (`id`, `name`, `email`, `xmpp_recipients`, `xmpp_group_recipients`, `priority`, `sort_priority`, `department_transfer_id`, `transfer_timeout`, `exclude_inactive_chats`, `delay_before_assign`, `max_ac_dep_chats`, `disabled`, `hidden`, `delay_lm`, `max_active_chats`, `max_timeout_seconds`, `identifier`, `mod_start_hour`, `mod_end_hour`, `tud_start_hour`, `tud_end_hour`, `wed_start_hour`, `wed_end_hour`, `thd_start_hour`, `thd_end_hour`, `frd_start_hour`, `frd_end_hour`, `sad_start_hour`, `sad_end_hour`, `sud_start_hour`, `sud_end_hour`, `nc_cb_execute`, `na_cb_execute`, `inform_unread`, `active_balancing`, `visible_if_online`, `inform_close`, `inform_unread_delay`, `inform_options`, `online_hours_active`, `inform_delay`, `attr_int_1`, `attr_int_2`, `attr_int_3`, `pending_max`, `pending_group_max`, `active_chats_counter`, `pending_chats_counter`, `closed_chats_counter`, `inform_close_all`, `inform_close_all_email`, `product_configuration`, `bot_configuration`) VALUES
(1, 'Lawfirm', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 15, 0, 1, 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament_availability`
--

CREATE TABLE `lh_departament_availability` (
  `id` bigint(20) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `hour` int(11) NOT NULL,
  `hourminute` int(4) NOT NULL,
  `minute` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `ymdhi` bigint(20) NOT NULL,
  `ymd` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament_custom_work_hours`
--

CREATE TABLE `lh_departament_custom_work_hours` (
  `id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `date_from` int(11) NOT NULL,
  `date_to` int(11) NOT NULL,
  `start_hour` int(11) NOT NULL,
  `end_hour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament_group`
--

CREATE TABLE `lh_departament_group` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament_group_member`
--

CREATE TABLE `lh_departament_group_member` (
  `id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `dep_group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament_group_user`
--

CREATE TABLE `lh_departament_group_user` (
  `id` int(11) NOT NULL,
  `dep_group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament_limit_group`
--

CREATE TABLE `lh_departament_limit_group` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pending_max` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_departament_limit_group_member`
--

CREATE TABLE `lh_departament_limit_group_member` (
  `id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `dep_limit_group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_faq`
--

CREATE TABLE `lh_faq` (
  `id` int(11) NOT NULL,
  `question` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  `has_url` tinyint(1) NOT NULL,
  `is_wildcard` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_faq`
--

INSERT INTO `lh_faq` (`id`, `question`, `answer`, `url`, `email`, `identifier`, `active`, `has_url`, `is_wildcard`) VALUES
(1, 'Question1', 'Answer1', '', 'test@gmail.com', '', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lh_forgotpasswordhash`
--

CREATE TABLE `lh_forgotpasswordhash` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_generic_bot_bot`
--

CREATE TABLE `lh_generic_bot_bot` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_generic_bot_chat_event`
--

CREATE TABLE `lh_generic_bot_chat_event` (
  `id` bigint(20) NOT NULL,
  `chat_id` bigint(20) NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ctime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_generic_bot_chat_workflow`
--

CREATE TABLE `lh_generic_bot_chat_workflow` (
  `id` bigint(20) NOT NULL,
  `chat_id` bigint(20) NOT NULL,
  `trigger_id` bigint(20) NOT NULL,
  `identifier` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `collected_data` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_generic_bot_group`
--

CREATE TABLE `lh_generic_bot_group` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bot_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_generic_bot_payload`
--

CREATE TABLE `lh_generic_bot_payload` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bot_id` int(11) NOT NULL,
  `trigger_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_generic_bot_trigger`
--

CREATE TABLE `lh_generic_bot_trigger` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actions` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` bigint(20) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `default` int(11) NOT NULL,
  `default_unknown` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_generic_bot_trigger_event`
--

CREATE TABLE `lh_generic_bot_trigger_event` (
  `id` bigint(20) NOT NULL,
  `pattern` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trigger_id` bigint(20) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_group`
--

CREATE TABLE `lh_group` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disabled` tinyint(1) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_group`
--

INSERT INTO `lh_group` (`id`, `name`, `disabled`, `required`) VALUES
(1, 'Administrators', 0, 0),
(2, 'Operators', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lh_grouprole`
--

CREATE TABLE `lh_grouprole` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_grouprole`
--

INSERT INTO `lh_grouprole` (`id`, `group_id`, `role_id`) VALUES
(1, 1, 1),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `lh_groupuser`
--

CREATE TABLE `lh_groupuser` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_groupuser`
--

INSERT INTO `lh_groupuser` (`id`, `group_id`, `user_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lh_group_object`
--

CREATE TABLE `lh_group_object` (
  `id` bigint(20) NOT NULL,
  `object_id` bigint(20) NOT NULL,
  `group_id` bigint(20) NOT NULL,
  `type` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_group_work`
--

CREATE TABLE `lh_group_work` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `group_work_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_msg`
--

CREATE TABLE `lh_msg` (
  `id` int(11) NOT NULL,
  `msg` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_msg` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name_support` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_msg`
--

INSERT INTO `lh_msg` (`id`, `msg`, `meta_msg`, `time`, `chat_id`, `user_id`, `name_support`) VALUES
(1, 'This is a test message.', '', 1526283666, 1, 0, ''),
(2, 'Admin has accepted the chat!', '', 1526283680, 1, -1, ''),
(3, 'hi', '', 1526283687, 1, 1, 'Admin'),
(4, 'Test Chat2', '', 1526284104, 2, 0, ''),
(5, 'Test Chat1', '', 1526284114, 3, 0, ''),
(6, 'ddd', '', 1526284207, 3, 0, ''),
(7, 'Admin has accepted the chat!', '', 1526284226, 2, -1, ''),
(8, 'Admin has accepted the chat!', '', 1526284244, 3, -1, ''),
(9, 'hi', '', 1526284250, 3, 1, 'Admin'),
(10, '👇', '', 1526284270, 3, 0, ''),
(11, 'user', '', 1526286206, 4, 0, ''),
(12, 'Admin has accepted the chat!', '', 1526286261, 4, -1, ''),
(13, 'ff', '', 1526286264, 4, 1, 'Admin'),
(14, 'what is ur first school name?', '', 1526286446, 5, 0, ''),
(15, 'Admin has accepted the chat!', '', 1526286453, 5, -1, ''),
(16, 'welcome', '', 1526286457, 5, 1, 'Admin'),
(17, 'what is the other box', '', 1526286508, 5, 0, ''),
(18, 'which one', '', 1526286520, 5, 1, 'Admin'),
(19, 'no', '', 1526286530, 5, 0, ''),
(20, 'just press enter', '', 1526286558, 5, 1, 'Admin'),
(21, 'there is no send button we have to press enter to send', '', 1526286559, 5, 0, ''),
(22, 'sxnckbsbvjbx adjbs cnzanbcskjsdabvcjk sajbkwsqjb', '', 1526286583, 5, 0, ''),
(23, 'jndjvcnkzxnkjvfnsakvnK\ncmvlcmxzlmv', '', 1526286606, 5, 0, ''),
(24, ';al,c[;zx,<\nfxkcfvlm\n;v;x,zc\nlv,c', '', 1526286618, 5, 0, ''),
(25, 'dfgdfg', '', 1526286837, 5, 1, 'Admin'),
(26, '[file=1_db4fa9f368e21bdf13fcab6fc928ef16]', '', 1526286875, 5, 1, 'Admin'),
(27, 'Visitor has closed the chat explicitly!', '', 1526290212, 4, -1, ''),
(29, 'Test', '', 1526294217, 7, 0, ''),
(30, 'Admin has accepted the chat!', '', 1526294297, 7, -1, ''),
(31, 'ff', '', 1526294319, 7, 1, 'Admin'),
(32, 'ddsd', '', 1526295291, 7, 0, ''),
(35, 'sfsdfsdf', '', 1526296406, 10, 0, ''),
(36, 'sdfsd', '', 1526296612, 11, 0, ''),
(37, 'sdfsdf', '', 1526296681, 12, 0, ''),
(38, 'Administrator (muralikumar.krishnamurthy@gmail.com) has redirected visitor to contact form!', '', 1526296779, 12, -1, ''),
(39, 'Visitor has been redirected to contact form', '', 1526296782, 12, -1, ''),
(40, 'Administrator (muralikumar.krishnamurthy@gmail.com) has redirected visitor to contact form!', '', 1526296784, 11, -1, ''),
(41, 'Admin has accepted the chat!', '', 1526296787, 10, -1, ''),
(42, 'Test', '', 1526296860, 13, 0, ''),
(43, 'Admin has accepted the chat!', '', 1526296887, 13, -1, ''),
(44, 'dddd', '', 1526296917, 13, 0, ''),
(45, 'Administrator (muralikumar.krishnamurthy@gmail.com) has closed the chat!', '', 1526296935, 7, -1, ''),
(46, 'rrrrr', '', 1526297109, 13, 1, 'Admin'),
(48, 'Test', '', 1526297275, 15, 0, ''),
(49, 'Administrator (muralikumar.krishnamurthy@gmail.com) has redirected visitor to contact form!', '', 1526297285, 15, -1, ''),
(50, 'Visitor has been redirected to contact form', '', 1526297287, 15, -1, ''),
(51, 'Visitor has closed the chat explicitly!', '', 1526297464, 13, -1, ''),
(52, 'hi', '', 1526298506, 5, 1, 'Admin'),
(53, 'see the time now', '', 1526298548, 5, 1, 'Admin'),
(54, 'r u there', '', 1526298963, 5, 1, 'Admin'),
(55, 'what is u r fav color?', '', 1526299035, 16, 0, ''),
(56, 'Admin has accepted the chat!', '', 1526299072, 16, -1, ''),
(57, 'blue', '', 1526299083, 16, 1, 'Admin'),
(58, 'and yours?', '', 1526300146, 16, 1, 'Admin'),
(59, 'HI😃', '', 1526300294, 17, 0, 'Visitor_465'),
(60, 'hi', '', 1526300327, 17, 1, 'Admin'),
(61, 'hi', '', 1526300652, 18, 0, ''),
(62, 'test', '', 1526302491, 19, 0, ''),
(63, 'Admin has accepted the chat!', '', 1526302507, 19, -1, ''),
(64, 'hi', '', 1526302525, 19, 1, 'Admin'),
(65, 'hru', '', 1526302537, 19, 0, ''),
(66, 'fine', '', 1526302548, 19, 1, 'Admin'),
(67, 'sdfs', '', 1526303771, 20, 0, ''),
(68, 'Admin has accepted the chat!', '', 1526303781, 20, -1, ''),
(69, 'sdfsdsdfsf', '', 1526303784, 20, 1, 'Admin'),
(70, 'Test message', '', 1526303991, 21, 0, ''),
(71, 'Admin has accepted the chat!', '', 1526304000, 21, -1, ''),
(72, 'sdfsd', '', 1526304003, 21, 1, 'Admin'),
(73, 'Admin has accepted the chat!', '', 1526304004, 18, -1, ''),
(74, 'sfsd', '', 1526304006, 18, 1, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `lh_question`
--

CREATE TABLE `lh_question` (
  `id` int(11) NOT NULL,
  `question` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `is_voting` int(11) NOT NULL,
  `question_intro` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `revote` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_question_answer`
--

CREATE TABLE `lh_question_answer` (
  `id` int(11) NOT NULL,
  `ip` bigint(20) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ctime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_question_option`
--

CREATE TABLE `lh_question_option` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `option_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_question_option_answer`
--

CREATE TABLE `lh_question_option_answer` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  `ip` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_role`
--

CREATE TABLE `lh_role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_role`
--

INSERT INTO `lh_role` (`id`, `name`) VALUES
(1, 'Administrators'),
(2, 'Operators');

-- --------------------------------------------------------

--
-- Table structure for table `lh_rolefunction`
--

CREATE TABLE `lh_rolefunction` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `function` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `limitation` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_rolefunction`
--

INSERT INTO `lh_rolefunction` (`id`, `role_id`, `module`, `function`, `limitation`) VALUES
(1, 1, '*', '*', ''),
(2, 2, 'lhuser', 'selfedit', ''),
(3, 2, 'lhuser', 'changeonlinestatus', ''),
(4, 2, 'lhuser', 'changeskypenick', ''),
(5, 2, 'lhuser', 'personalcannedmsg', ''),
(6, 2, 'lhuser', 'change_visibility_list', ''),
(7, 2, 'lhuser', 'see_assigned_departments', ''),
(8, 2, 'lhuser', 'canseedepartmentstats', ''),
(9, 2, 'lhchat', 'use', ''),
(10, 2, 'lhchat', 'chattabschrome', ''),
(11, 2, 'lhchat', 'singlechatwindow', ''),
(12, 2, 'lhchat', 'allowopenremotechat', ''),
(13, 2, 'lhchat', 'allowchattabs', ''),
(14, 2, 'lhchat', 'use_onlineusers', ''),
(15, 2, 'lhchat', 'take_screenshot', ''),
(16, 2, 'lhfront', 'use', ''),
(17, 2, 'lhsystem', 'use', ''),
(18, 2, 'lhtranslation', 'use', ''),
(19, 2, 'lhchat', 'allowblockusers', ''),
(20, 2, 'lhsystem', 'generatejs', ''),
(21, 2, 'lhsystem', 'changelanguage', ''),
(22, 2, 'lhchat', 'allowredirect', ''),
(23, 2, 'lhchat', 'allowtransfer', ''),
(24, 2, 'lhchat', 'allowtransferdirectly', ''),
(25, 2, 'lhchat', 'administratecannedmsg', ''),
(26, 2, 'lhchat', 'sees_all_online_visitors', ''),
(27, 2, 'lhpermission', 'see_permissions', ''),
(28, 2, 'lhquestionary', 'manage_questionary', ''),
(29, 2, 'lhfaq', 'manage_faq', ''),
(30, 2, 'lhchatbox', 'manage_chatbox', ''),
(31, 2, 'lhbrowseoffer', 'manage_bo', ''),
(32, 2, 'lhxml', '*', ''),
(33, 2, 'lhcobrowse', 'browse', ''),
(34, 2, 'lhfile', 'use_operator', ''),
(35, 2, 'lhfile', 'file_delete_chat', ''),
(36, 2, 'lhstatistic', 'use', ''),
(37, 2, 'lhspeech', 'changedefaultlanguage', ''),
(38, 2, 'lhspeech', 'use', ''),
(39, 2, 'lhcannedmsg', 'use', ''),
(40, 2, 'lhspeech', 'change_chat_recognition', '');

-- --------------------------------------------------------

--
-- Table structure for table `lh_speech_chat_language`
--

CREATE TABLE `lh_speech_chat_language` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `dialect` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_speech_language`
--

CREATE TABLE `lh_speech_language` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_speech_language`
--

INSERT INTO `lh_speech_language` (`id`, `name`) VALUES
(1, 'Afrikaans'),
(2, 'Bahasa Indonesia'),
(3, 'Bahasa Melayu'),
(4, 'Català'),
(5, 'Čeština'),
(6, 'Deutsch'),
(7, 'English'),
(8, 'Español'),
(9, 'Euskara'),
(10, 'Français'),
(11, 'Galego'),
(12, 'Hrvatski'),
(13, 'IsiZulu'),
(14, 'Íslenska'),
(15, 'Italiano'),
(16, 'Magyar'),
(17, 'Nederlands'),
(18, 'Norsk bokmål'),
(19, 'Polski'),
(20, 'Português'),
(21, 'Română'),
(22, 'Slovenčina'),
(23, 'Suomi'),
(24, 'Svenska'),
(25, 'Türkçe'),
(26, 'български'),
(27, 'Pусский'),
(28, 'Српски'),
(29, '한국어'),
(30, '中文'),
(31, '日本語'),
(32, 'Lingua latīna');

-- --------------------------------------------------------

--
-- Table structure for table `lh_speech_language_dialect`
--

CREATE TABLE `lh_speech_language_dialect` (
  `id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `lang_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_code` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_speech_language_dialect`
--

INSERT INTO `lh_speech_language_dialect` (`id`, `language_id`, `lang_name`, `lang_code`, `short_code`) VALUES
(1, 1, 'Afrikaans', 'af-ZA', ''),
(2, 2, 'Bahasa Indonesia', 'id-ID', ''),
(3, 3, 'Bahasa Melayu', 'ms-MY', ''),
(4, 4, 'Català', 'ca-ES', ''),
(5, 5, 'Čeština', 'cs-CZ', ''),
(6, 6, 'Deutsch', 'de-DE', ''),
(7, 7, 'Australia', 'en-AU', ''),
(8, 7, 'Canada', 'en-CA', ''),
(9, 7, 'India', 'en-IN', ''),
(10, 7, 'New Zealand', 'en-NZ', ''),
(11, 7, 'South Africa', 'en-ZA', ''),
(12, 7, 'United Kingdom', 'en-GB', ''),
(13, 7, 'United States', 'en-US', ''),
(14, 8, 'Argentina', 'es-AR', ''),
(15, 8, 'Bolivia', 'es-BO', ''),
(16, 8, 'Chile', 'es-CL', ''),
(17, 8, 'Colombia', 'es-CO', ''),
(18, 8, 'Costa Rica', 'es-CR', ''),
(19, 8, 'Ecuador', 'es-EC', ''),
(20, 8, 'El Salvador', 'es-SV', ''),
(21, 8, 'España', 'es-ES', ''),
(22, 8, 'Estados Unidos', 'es-US', ''),
(23, 8, 'Guatemala', 'es-GT', ''),
(24, 8, 'Honduras', 'es-HN', ''),
(25, 8, 'México', 'es-MX', ''),
(26, 8, 'Nicaragua', 'es-NI', ''),
(27, 8, 'Panamá', 'es-PA', ''),
(28, 8, 'Paraguay', 'es-PY', ''),
(29, 8, 'Perú', 'es-PE', ''),
(30, 8, 'Puerto Rico', 'es-PR', ''),
(31, 8, 'República Dominicana', 'es-DO', ''),
(32, 8, 'Uruguay', 'es-UY', ''),
(33, 8, 'Venezuela', 'es-VE', ''),
(34, 9, 'Euskara', 'eu-ES', ''),
(35, 10, 'Français', 'fr-FR', ''),
(36, 11, 'Galego', 'gl-ES', ''),
(37, 12, 'Hrvatski', 'hr_HR', ''),
(38, 13, 'IsiZulu', 'zu-ZA', ''),
(39, 14, 'Íslenska', 'is-IS', ''),
(40, 15, 'Italia', 'it-IT', ''),
(41, 15, 'Svizzera', 'it-CH', ''),
(42, 16, 'Magyar', 'hu-HU', ''),
(43, 17, 'Nederlands', 'nl-NL', ''),
(44, 18, 'Norsk bokmål', 'nb-NO', ''),
(45, 19, 'Polski', 'pl-PL', ''),
(46, 20, 'Brasil', 'pt-BR', ''),
(47, 20, 'Portugal', 'pt-PT', ''),
(48, 21, 'Română', 'ro-RO', ''),
(49, 22, 'Slovenčina', 'sk-SK', ''),
(50, 23, 'Suomi', 'fi-FI', ''),
(51, 24, 'Svenska', 'sv-SE', ''),
(52, 25, 'Türkçe', 'tr-TR', ''),
(53, 26, 'български', 'bg-BG', ''),
(54, 27, 'Pусский', 'ru-RU', ''),
(55, 28, 'Српски', 'sr-RS', ''),
(56, 29, '한국어', 'ko-KR', ''),
(57, 30, '普通话 (中国大陆)', 'cmn-Hans-CN', ''),
(58, 30, '普通话 (香港)', 'cmn-Hans-HK', ''),
(59, 30, '中文 (台灣)', 'cmn-Hant-TW', ''),
(60, 30, '粵語 (香港)', 'yue-Hant-HK', ''),
(61, 31, '日本語', 'ja-JP', ''),
(62, 32, 'Lingua latīna', 'la', '');

-- --------------------------------------------------------

--
-- Table structure for table `lh_transfer`
--

CREATE TABLE `lh_transfer` (
  `id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `transfer_user_id` int(11) NOT NULL,
  `from_dep_id` int(11) NOT NULL,
  `ctime` int(11) NOT NULL,
  `transfer_to_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_userdep`
--

CREATE TABLE `lh_userdep` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dep_id` int(11) NOT NULL,
  `last_activity` int(11) NOT NULL,
  `exclude_autoasign` tinyint(1) NOT NULL DEFAULT '0',
  `hide_online` int(11) NOT NULL,
  `last_accepted` int(11) NOT NULL,
  `active_chats` int(11) NOT NULL,
  `pending_chats` int(11) NOT NULL DEFAULT '0',
  `inactive_chats` int(11) NOT NULL DEFAULT '0',
  `max_chats` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `ro` tinyint(1) NOT NULL DEFAULT '0',
  `hide_online_ts` int(11) NOT NULL DEFAULT '0',
  `dep_group_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_userdep`
--

INSERT INTO `lh_userdep` (`id`, `user_id`, `dep_id`, `last_activity`, `exclude_autoasign`, `hide_online`, `last_accepted`, `active_chats`, `pending_chats`, `inactive_chats`, `max_chats`, `type`, `ro`, `hide_online_ts`, `dep_group_id`) VALUES
(1, 1, 0, 1526304931, 0, 0, 0, 15, 0, 2, 0, 0, 0, 1526303966, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lh_users`
--

CREATE TABLE `lh_users` (
  `id` int(11) NOT NULL,
  `username` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_zone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filepath` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departments_ids` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chat_nickname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `xmpp_username` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_admin` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `skype` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exclude_autoasign` tinyint(1) NOT NULL,
  `disabled` tinyint(4) NOT NULL,
  `hide_online` tinyint(1) NOT NULL,
  `all_departments` tinyint(1) NOT NULL,
  `invisible_mode` tinyint(1) NOT NULL,
  `inactive_mode` tinyint(1) NOT NULL,
  `rec_per_req` tinyint(1) NOT NULL,
  `active_chats_counter` int(11) NOT NULL,
  `closed_chats_counter` int(11) NOT NULL,
  `pending_chats_counter` int(11) NOT NULL,
  `auto_accept` tinyint(1) NOT NULL,
  `max_active_chats` int(11) NOT NULL,
  `attr_int_1` int(11) NOT NULL,
  `attr_int_2` int(11) NOT NULL,
  `attr_int_3` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_users`
--

INSERT INTO `lh_users` (`id`, `username`, `password`, `email`, `time_zone`, `name`, `surname`, `filepath`, `filename`, `job_title`, `departments_ids`, `chat_nickname`, `xmpp_username`, `session_id`, `operation_admin`, `skype`, `exclude_autoasign`, `disabled`, `hide_online`, `all_departments`, `invisible_mode`, `inactive_mode`, `rec_per_req`, `active_chats_counter`, `closed_chats_counter`, `pending_chats_counter`, `auto_accept`, `max_active_chats`, `attr_int_1`, `attr_int_2`, `attr_int_3`) VALUES
(1, 'Administrator', '$2y$10$kPDz2jP0fqm1eRaB7GDQPOyncttFysIeMjB0lXFQczZOLAWmSP5bC', 'muralikumar.krishnamurthy@gmail.com', '', 'Admin', '', 'var/userphoto/2018y/05/14/1/', '1cee089f1fdc294b5651b00163613955.jpg', '', '0', '', '', '', '', '', 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lh_users_online_session`
--

CREATE TABLE `lh_users_online_session` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `lactivity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_users_online_session`
--

INSERT INTO `lh_users_online_session` (`id`, `user_id`, `time`, `duration`, `lactivity`) VALUES
(1, 1, 1526283639, 1920, 1526285559),
(2, 1, 1526286116, 2696, 1526288812),
(3, 1, 1526290194, 13692, 1526303886),
(4, 1, 1526303936, 995, 1526304931);

-- --------------------------------------------------------

--
-- Table structure for table `lh_users_remember`
--

CREATE TABLE `lh_users_remember` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `mtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_users_session`
--

CREATE TABLE `lh_users_session` (
  `id` int(11) NOT NULL,
  `token` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` int(11) NOT NULL,
  `device_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_on` int(11) NOT NULL,
  `updated_on` int(11) NOT NULL,
  `expires_on` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lh_users_setting`
--

CREATE TABLE `lh_users_setting` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_users_setting`
--

INSERT INTO `lh_users_setting` (`id`, `user_id`, `identifier`, `value`) VALUES
(1, 1, 'enable_bot_list', '0'),
(2, 1, 'show_all_pending', '1'),
(3, 1, 'user_language', 'en_EN'),
(4, 1, 'enable_pending_list', '1'),
(5, 1, 'enable_active_list', '1'),
(6, 1, 'enable_close_list', '0'),
(7, 1, 'enable_unread_list', '1'),
(8, 1, 'enable_mchats_list', '0'),
(9, 1, 'new_user_bn', '0'),
(10, 1, 'new_user_sound', '0'),
(11, 1, 'o_department', '0'),
(12, 1, 'ouser_timeout', '3600'),
(13, 1, 'oupdate_timeout', '10'),
(14, 1, 'omax_rows', '50'),
(15, 1, 'ogroup_by', 'none'),
(16, 1, 'omap_depid', '0'),
(17, 1, 'omap_mtimeout', '30'),
(18, 1, 'dwo', ''),
(19, 1, 'new_chat_sound', '1'),
(20, 1, 'chat_message', '1'),
(21, 1, 'show_alert_chat', '0'),
(22, 1, 'sn_off', '1'),
(23, 1, 'ownntfonly', '0'),
(24, 1, 'show_alert_transfer', '1'),
(25, 1, 'trackactivitytimeout', '-1'),
(26, 1, 'trackactivity', '0'),
(27, 1, 'auto_preload', '0'),
(28, 1, 'speech_language', ''),
(29, 1, 'speech_dialect', '');

-- --------------------------------------------------------

--
-- Table structure for table `lh_users_setting_option`
--

CREATE TABLE `lh_users_setting_option` (
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lh_users_setting_option`
--

INSERT INTO `lh_users_setting_option` (`identifier`, `class`, `attribute`) VALUES
('chat_message', '', ''),
('dwo', '', ''),
('enable_active_list', '', ''),
('enable_close_list', '', ''),
('enable_pending_list', '', ''),
('enable_unread_list', '', ''),
('new_chat_sound', '', ''),
('new_user_bn', '', ''),
('new_user_sound', '', ''),
('o_department', '', ''),
('ogroup_by', '', ''),
('omap_depid', '', ''),
('omap_mtimeout', '', ''),
('omax_rows', '', ''),
('oupdate_timeout', '', ''),
('ouser_timeout', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lh_abstract_auto_responder`
--
ALTER TABLE `lh_abstract_auto_responder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `siteaccess_position` (`siteaccess`,`position`);

--
-- Indexes for table `lh_abstract_auto_responder_chat`
--
ALTER TABLE `lh_abstract_auto_responder_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `lh_abstract_browse_offer_invitation`
--
ALTER TABLE `lh_abstract_browse_offer_invitation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`),
  ADD KEY `identifier` (`identifier`);

--
-- Indexes for table `lh_abstract_email_template`
--
ALTER TABLE `lh_abstract_email_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_abstract_form`
--
ALTER TABLE `lh_abstract_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_abstract_form_collected`
--
ALTER TABLE `lh_abstract_form_collected`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `lh_abstract_proactive_chat_event`
--
ALTER TABLE `lh_abstract_proactive_chat_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vid_id_ev_id_val_ts` (`vid_id`,`ev_id`,`val`,`ts`),
  ADD KEY `vid_id_ev_id_ts` (`vid_id`,`ev_id`,`ts`);

--
-- Indexes for table `lh_abstract_proactive_chat_invitation`
--
ALTER TABLE `lh_abstract_proactive_chat_invitation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `time_on_site_pageviews_siteaccess_position` (`time_on_site`,`pageviews`,`siteaccess`,`identifier`,`position`),
  ADD KEY `identifier` (`identifier`),
  ADD KEY `dynamic_invitation` (`dynamic_invitation`),
  ADD KEY `tag` (`tag`),
  ADD KEY `dep_id` (`dep_id`);

--
-- Indexes for table `lh_abstract_proactive_chat_invitation_event`
--
ALTER TABLE `lh_abstract_proactive_chat_invitation_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invitation_id` (`invitation_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `lh_abstract_proactive_chat_variables`
--
ALTER TABLE `lh_abstract_proactive_chat_variables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `identifier` (`identifier`);

--
-- Indexes for table `lh_abstract_product`
--
ALTER TABLE `lh_abstract_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `departament_id` (`departament_id`);

--
-- Indexes for table `lh_abstract_product_departament`
--
ALTER TABLE `lh_abstract_product_departament`
  ADD PRIMARY KEY (`id`),
  ADD KEY `departament_id` (`departament_id`);

--
-- Indexes for table `lh_abstract_rest_api_key`
--
ALTER TABLE `lh_abstract_rest_api_key`
  ADD PRIMARY KEY (`id`),
  ADD KEY `api_key` (`api_key`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `lh_abstract_subject`
--
ALTER TABLE `lh_abstract_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_abstract_subject_chat`
--
ALTER TABLE `lh_abstract_subject_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `lh_abstract_subject_dep`
--
ALTER TABLE `lh_abstract_subject_dep`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `lh_abstract_survey`
--
ALTER TABLE `lh_abstract_survey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_abstract_survey_item`
--
ALTER TABLE `lh_abstract_survey_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `survey_id` (`survey_id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `dep_id` (`dep_id`),
  ADD KEY `ftime` (`ftime`),
  ADD KEY `max_stars_1` (`max_stars_1`),
  ADD KEY `max_stars_2` (`max_stars_2`),
  ADD KEY `max_stars_3` (`max_stars_3`),
  ADD KEY `max_stars_4` (`max_stars_4`),
  ADD KEY `max_stars_5` (`max_stars_5`),
  ADD KEY `question_options_1` (`question_options_1`),
  ADD KEY `question_options_2` (`question_options_2`),
  ADD KEY `question_options_3` (`question_options_3`),
  ADD KEY `question_options_4` (`question_options_4`),
  ADD KEY `question_options_5` (`question_options_5`);

--
-- Indexes for table `lh_abstract_widget_theme`
--
ALTER TABLE `lh_abstract_widget_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_admin_theme`
--
ALTER TABLE `lh_admin_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_canned_msg`
--
ALTER TABLE `lh_canned_msg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `attr_int_1` (`attr_int_1`),
  ADD KEY `attr_int_2` (`attr_int_2`),
  ADD KEY `attr_int_3` (`attr_int_3`),
  ADD KEY `position_title_v2` (`position`,`title`(191)),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `lh_canned_msg_tag`
--
ALTER TABLE `lh_canned_msg_tag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tag` (`tag`);

--
-- Indexes for table `lh_canned_msg_tag_link`
--
ALTER TABLE `lh_canned_msg_tag_link`
  ADD PRIMARY KEY (`id`),
  ADD KEY `canned_id` (`canned_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Indexes for table `lh_chat`
--
ALTER TABLE `lh_chat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status_user_id` (`status`,`user_id`),
  ADD KEY `user_id_sender_user_id` (`user_id`,`sender_user_id`),
  ADD KEY `unanswered_chat` (`unanswered_chat`),
  ADD KEY `sender_user_id` (`sender_user_id`),
  ADD KEY `online_user_id` (`online_user_id`),
  ADD KEY `dep_id` (`dep_id`),
  ADD KEY `anonymized` (`anonymized`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `unread_operator` (`has_unread_op_messages`,`unread_op_messages_informed`),
  ADD KEY `has_unread_messages_dep_id_id` (`has_unread_messages`,`dep_id`,`id`),
  ADD KEY `status_dep_id_id` (`status`,`dep_id`,`id`),
  ADD KEY `status_dep_id_priority_id` (`status`,`dep_id`,`priority`,`id`),
  ADD KEY `status_priority_id` (`status`,`priority`,`id`);

--
-- Indexes for table `lh_chatbox`
--
ALTER TABLE `lh_chatbox`
  ADD PRIMARY KEY (`id`),
  ADD KEY `identifier` (`identifier`);

--
-- Indexes for table `lh_chat_accept`
--
ALTER TABLE `lh_chat_accept`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`);

--
-- Indexes for table `lh_chat_archive_range`
--
ALTER TABLE `lh_chat_archive_range`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_chat_blocked_user`
--
ALTER TABLE `lh_chat_blocked_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `lh_chat_config`
--
ALTER TABLE `lh_chat_config`
  ADD PRIMARY KEY (`identifier`);

--
-- Indexes for table `lh_chat_file`
--
ALTER TABLE `lh_chat_file`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `online_user_id` (`online_user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `lh_chat_online_user`
--
ALTER TABLE `lh_chat_online_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vid` (`vid`),
  ADD KEY `dep_id` (`dep_id`),
  ADD KEY `last_visit_dep_id` (`last_visit`,`dep_id`);

--
-- Indexes for table `lh_chat_online_user_footprint`
--
ALTER TABLE `lh_chat_online_user_footprint`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `online_user_id` (`online_user_id`);

--
-- Indexes for table `lh_chat_paid`
--
ALTER TABLE `lh_chat_paid`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`(191)),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `lh_chat_start_settings`
--
ALTER TABLE `lh_chat_start_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `lh_cobrowse`
--
ALTER TABLE `lh_cobrowse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`),
  ADD KEY `online_user_id` (`online_user_id`);

--
-- Indexes for table `lh_departament`
--
ALTER TABLE `lh_departament`
  ADD PRIMARY KEY (`id`),
  ADD KEY `identifier` (`identifier`),
  ADD KEY `attr_int_1` (`attr_int_1`),
  ADD KEY `attr_int_2` (`attr_int_2`),
  ADD KEY `attr_int_3` (`attr_int_3`),
  ADD KEY `active_chats_counter` (`active_chats_counter`),
  ADD KEY `pending_chats_counter` (`pending_chats_counter`),
  ADD KEY `closed_chats_counter` (`closed_chats_counter`),
  ADD KEY `disabled_hidden` (`disabled`,`hidden`),
  ADD KEY `sort_priority_name` (`sort_priority`,`name`),
  ADD KEY `active_mod` (`online_hours_active`,`mod_start_hour`,`mod_end_hour`),
  ADD KEY `active_tud` (`online_hours_active`,`tud_start_hour`,`tud_end_hour`),
  ADD KEY `active_wed` (`online_hours_active`,`wed_start_hour`,`wed_end_hour`),
  ADD KEY `active_thd` (`online_hours_active`,`thd_start_hour`,`thd_end_hour`),
  ADD KEY `active_frd` (`online_hours_active`,`frd_start_hour`,`frd_end_hour`),
  ADD KEY `active_sad` (`online_hours_active`,`sad_start_hour`,`sad_end_hour`),
  ADD KEY `active_sud` (`online_hours_active`,`sud_start_hour`,`sud_end_hour`);

--
-- Indexes for table `lh_departament_availability`
--
ALTER TABLE `lh_departament_availability`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ymdhi` (`ymdhi`),
  ADD KEY `dep_id` (`dep_id`),
  ADD KEY `hourminute` (`hourminute`),
  ADD KEY `time` (`time`);

--
-- Indexes for table `lh_departament_custom_work_hours`
--
ALTER TABLE `lh_departament_custom_work_hours`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dep_id` (`dep_id`),
  ADD KEY `date_from` (`date_from`),
  ADD KEY `search_active` (`date_from`,`date_to`,`dep_id`);

--
-- Indexes for table `lh_departament_group`
--
ALTER TABLE `lh_departament_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_departament_group_member`
--
ALTER TABLE `lh_departament_group_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dep_group_id` (`dep_group_id`);

--
-- Indexes for table `lh_departament_group_user`
--
ALTER TABLE `lh_departament_group_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dep_group_id` (`dep_group_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `lh_departament_limit_group`
--
ALTER TABLE `lh_departament_limit_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_departament_limit_group_member`
--
ALTER TABLE `lh_departament_limit_group_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dep_limit_group_id` (`dep_limit_group_id`);

--
-- Indexes for table `lh_faq`
--
ALTER TABLE `lh_faq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`),
  ADD KEY `active_url_2` (`active`,`url`(191)),
  ADD KEY `has_url` (`has_url`),
  ADD KEY `identifier` (`identifier`),
  ADD KEY `is_wildcard` (`is_wildcard`);

--
-- Indexes for table `lh_forgotpasswordhash`
--
ALTER TABLE `lh_forgotpasswordhash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_generic_bot_bot`
--
ALTER TABLE `lh_generic_bot_bot`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_generic_bot_chat_event`
--
ALTER TABLE `lh_generic_bot_chat_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `lh_generic_bot_chat_workflow`
--
ALTER TABLE `lh_generic_bot_chat_workflow`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `lh_generic_bot_group`
--
ALTER TABLE `lh_generic_bot_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`);

--
-- Indexes for table `lh_generic_bot_payload`
--
ALTER TABLE `lh_generic_bot_payload`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`),
  ADD KEY `trigger_id` (`trigger_id`);

--
-- Indexes for table `lh_generic_bot_trigger`
--
ALTER TABLE `lh_generic_bot_trigger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`),
  ADD KEY `default_unknown` (`default_unknown`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `lh_generic_bot_trigger_event`
--
ALTER TABLE `lh_generic_bot_trigger_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pattern` (`pattern`),
  ADD KEY `type` (`type`),
  ADD KEY `trigger_id` (`trigger_id`);

--
-- Indexes for table `lh_group`
--
ALTER TABLE `lh_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `disabled` (`disabled`);

--
-- Indexes for table `lh_grouprole`
--
ALTER TABLE `lh_grouprole`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`role_id`,`group_id`),
  ADD KEY `group_id_primary` (`group_id`);

--
-- Indexes for table `lh_groupuser`
--
ALTER TABLE `lh_groupuser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `group_id_2` (`group_id`,`user_id`);

--
-- Indexes for table `lh_group_object`
--
ALTER TABLE `lh_group_object`
  ADD PRIMARY KEY (`id`),
  ADD KEY `object_id_type` (`object_id`,`type`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `lh_group_work`
--
ALTER TABLE `lh_group_work`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `lh_msg`
--
ALTER TABLE `lh_msg`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id_id` (`chat_id`,`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `lh_question`
--
ALTER TABLE `lh_question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `priority` (`priority`),
  ADD KEY `active_priority` (`active`,`priority`);

--
-- Indexes for table `lh_question_answer`
--
ALTER TABLE `lh_question_answer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip` (`ip`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `lh_question_option`
--
ALTER TABLE `lh_question_option`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `lh_question_option_answer`
--
ALTER TABLE `lh_question_option_answer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `ip` (`ip`);

--
-- Indexes for table `lh_role`
--
ALTER TABLE `lh_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_rolefunction`
--
ALTER TABLE `lh_rolefunction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `lh_speech_chat_language`
--
ALTER TABLE `lh_speech_chat_language`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_id` (`chat_id`);

--
-- Indexes for table `lh_speech_language`
--
ALTER TABLE `lh_speech_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_speech_language_dialect`
--
ALTER TABLE `lh_speech_language_dialect`
  ADD PRIMARY KEY (`id`),
  ADD KEY `language_id` (`language_id`),
  ADD KEY `short_code` (`short_code`),
  ADD KEY `lang_code` (`lang_code`);

--
-- Indexes for table `lh_transfer`
--
ALTER TABLE `lh_transfer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dep_id` (`dep_id`),
  ADD KEY `transfer_user_id_dep_id` (`transfer_user_id`,`dep_id`),
  ADD KEY `transfer_to_user_id` (`transfer_to_user_id`);

--
-- Indexes for table `lh_userdep`
--
ALTER TABLE `lh_userdep`
  ADD PRIMARY KEY (`id`),
  ADD KEY `last_activity_hide_online_dep_id` (`last_activity`,`hide_online`,`dep_id`),
  ADD KEY `dep_id` (`dep_id`),
  ADD KEY `user_id_type` (`user_id`,`type`);

--
-- Indexes for table `lh_users`
--
ALTER TABLE `lh_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hide_online` (`hide_online`),
  ADD KEY `rec_per_req` (`rec_per_req`),
  ADD KEY `email` (`email`),
  ADD KEY `xmpp_username` (`xmpp_username`(191));

--
-- Indexes for table `lh_users_online_session`
--
ALTER TABLE `lh_users_online_session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id_lactivity` (`user_id`,`lactivity`);

--
-- Indexes for table `lh_users_remember`
--
ALTER TABLE `lh_users_remember`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lh_users_session`
--
ALTER TABLE `lh_users_session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `device_token_device_type_v2` (`device_token`(191),`device_type`),
  ADD KEY `token` (`token`);

--
-- Indexes for table `lh_users_setting`
--
ALTER TABLE `lh_users_setting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`,`identifier`);

--
-- Indexes for table `lh_users_setting_option`
--
ALTER TABLE `lh_users_setting_option`
  ADD PRIMARY KEY (`identifier`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lh_abstract_auto_responder`
--
ALTER TABLE `lh_abstract_auto_responder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_auto_responder_chat`
--
ALTER TABLE `lh_abstract_auto_responder_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_browse_offer_invitation`
--
ALTER TABLE `lh_abstract_browse_offer_invitation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_email_template`
--
ALTER TABLE `lh_abstract_email_template`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `lh_abstract_form`
--
ALTER TABLE `lh_abstract_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_form_collected`
--
ALTER TABLE `lh_abstract_form_collected`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_proactive_chat_event`
--
ALTER TABLE `lh_abstract_proactive_chat_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_proactive_chat_invitation`
--
ALTER TABLE `lh_abstract_proactive_chat_invitation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_proactive_chat_invitation_event`
--
ALTER TABLE `lh_abstract_proactive_chat_invitation_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_proactive_chat_variables`
--
ALTER TABLE `lh_abstract_proactive_chat_variables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_product`
--
ALTER TABLE `lh_abstract_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_product_departament`
--
ALTER TABLE `lh_abstract_product_departament`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_rest_api_key`
--
ALTER TABLE `lh_abstract_rest_api_key`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_subject`
--
ALTER TABLE `lh_abstract_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_subject_chat`
--
ALTER TABLE `lh_abstract_subject_chat`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_subject_dep`
--
ALTER TABLE `lh_abstract_subject_dep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_survey`
--
ALTER TABLE `lh_abstract_survey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_survey_item`
--
ALTER TABLE `lh_abstract_survey_item`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_abstract_widget_theme`
--
ALTER TABLE `lh_abstract_widget_theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_admin_theme`
--
ALTER TABLE `lh_admin_theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_canned_msg`
--
ALTER TABLE `lh_canned_msg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_canned_msg_tag`
--
ALTER TABLE `lh_canned_msg_tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_canned_msg_tag_link`
--
ALTER TABLE `lh_canned_msg_tag_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_chat`
--
ALTER TABLE `lh_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `lh_chatbox`
--
ALTER TABLE `lh_chatbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lh_chat_accept`
--
ALTER TABLE `lh_chat_accept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_chat_archive_range`
--
ALTER TABLE `lh_chat_archive_range`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_chat_blocked_user`
--
ALTER TABLE `lh_chat_blocked_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_chat_file`
--
ALTER TABLE `lh_chat_file`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lh_chat_online_user`
--
ALTER TABLE `lh_chat_online_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `lh_chat_online_user_footprint`
--
ALTER TABLE `lh_chat_online_user_footprint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_chat_paid`
--
ALTER TABLE `lh_chat_paid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_chat_start_settings`
--
ALTER TABLE `lh_chat_start_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_cobrowse`
--
ALTER TABLE `lh_cobrowse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_departament`
--
ALTER TABLE `lh_departament`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lh_departament_availability`
--
ALTER TABLE `lh_departament_availability`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_departament_custom_work_hours`
--
ALTER TABLE `lh_departament_custom_work_hours`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_departament_group`
--
ALTER TABLE `lh_departament_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_departament_group_member`
--
ALTER TABLE `lh_departament_group_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_departament_group_user`
--
ALTER TABLE `lh_departament_group_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_departament_limit_group`
--
ALTER TABLE `lh_departament_limit_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_departament_limit_group_member`
--
ALTER TABLE `lh_departament_limit_group_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_faq`
--
ALTER TABLE `lh_faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lh_forgotpasswordhash`
--
ALTER TABLE `lh_forgotpasswordhash`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_generic_bot_bot`
--
ALTER TABLE `lh_generic_bot_bot`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_generic_bot_chat_event`
--
ALTER TABLE `lh_generic_bot_chat_event`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_generic_bot_chat_workflow`
--
ALTER TABLE `lh_generic_bot_chat_workflow`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_generic_bot_group`
--
ALTER TABLE `lh_generic_bot_group`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_generic_bot_payload`
--
ALTER TABLE `lh_generic_bot_payload`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_generic_bot_trigger`
--
ALTER TABLE `lh_generic_bot_trigger`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_generic_bot_trigger_event`
--
ALTER TABLE `lh_generic_bot_trigger_event`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_group`
--
ALTER TABLE `lh_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lh_grouprole`
--
ALTER TABLE `lh_grouprole`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lh_groupuser`
--
ALTER TABLE `lh_groupuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lh_group_object`
--
ALTER TABLE `lh_group_object`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_group_work`
--
ALTER TABLE `lh_group_work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_msg`
--
ALTER TABLE `lh_msg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `lh_question`
--
ALTER TABLE `lh_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_question_answer`
--
ALTER TABLE `lh_question_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_question_option`
--
ALTER TABLE `lh_question_option`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_question_option_answer`
--
ALTER TABLE `lh_question_option_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_role`
--
ALTER TABLE `lh_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lh_rolefunction`
--
ALTER TABLE `lh_rolefunction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `lh_speech_chat_language`
--
ALTER TABLE `lh_speech_chat_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_speech_language`
--
ALTER TABLE `lh_speech_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `lh_speech_language_dialect`
--
ALTER TABLE `lh_speech_language_dialect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `lh_transfer`
--
ALTER TABLE `lh_transfer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_userdep`
--
ALTER TABLE `lh_userdep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lh_users`
--
ALTER TABLE `lh_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lh_users_online_session`
--
ALTER TABLE `lh_users_online_session`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lh_users_remember`
--
ALTER TABLE `lh_users_remember`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_users_session`
--
ALTER TABLE `lh_users_session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lh_users_setting`
--
ALTER TABLE `lh_users_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
