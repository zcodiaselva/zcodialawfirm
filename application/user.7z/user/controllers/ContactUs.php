<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ContactUs extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('home_model');
    }

    public function index() {
        $data['contactus_address'] = $this->home_model->getData('c_name,c_content,c_icon', 'contactus', array('c_status' => 1, 'c_deleted' => 0, 'c_type' => 1));
        $data['contactus_social'] = $this->home_model->getData('c_social_link,c_social_name', 'contactus', array('c_status' => 1, 'c_deleted' => 0, 'c_type' => 2));
        $data['contactus_footer'] = $this->home_model->getData('c_footer_content', 'contactus', array('c_status' => 1, 'c_deleted' => 0, 'c_type' => 3));


        $this->load->view('template/header');
        $this->load->view('contact-us');
        $this->load->view('template/footer', $data);
    }

    public function slider() {
        $this->load->view('temp');
    }

}
