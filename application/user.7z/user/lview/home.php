<?php
$tm_bg_image = '';
if (isset($home_testimonial_bg_image) && !empty($home_testimonial_bg_image)) {
    $tm_bg_image = $home_testimonial_bg_image[0]['tmimg_bg'];
}
$hsb_text1 = $hsb_text2 = $hsb_buttonImage = $hsb_buttonLink = '';
if (isset($home_sliderbox_details) && !empty($home_sliderbox_details)) {
    $hsb_text1 = $home_sliderbox_details[0]['hsb_percentage'];
    $hsb_text2 = $home_sliderbox_details[0]['hsb_text'];
    $hsb_buttonImage = $home_sliderbox_details[0]['hsb_buttonimage'];
    $hsb_buttonLink = $home_sliderbox_details[0]['hsb_buttonlink'];
}

$pa_header = $pa_subheader = $pa_content = $pa_image = $pa_sideimage = $pa_buttontext = $pa_buttonlink = '';
if (isset($home_practiceareas) && !empty($home_practiceareas)) {
    $pa_header = $home_practiceareas[0]['pa_mainheader'];
    $pa_subheader = $home_practiceareas[0]['pa_subheader'];
    $pa_content = $home_practiceareas[0]['pa_content'];
    $pa_image = $home_practiceareas[0]['pa_image'];
    $pa_sideimage = $home_practiceareas[0]['pa_sideimage'];
    $pa_buttontext = $home_practiceareas[0]['pa_buttontext'];
    $pa_buttonlink = $home_practiceareas[0]['pa_buttonlink'];
}
?>

<div id="Header_wrapper">
    <header id="Header">
        <div class="header_placeholder"></div>
        <?php include APPPATH . 'views/template/top_menu.php'; ?>
        <?php include APPPATH . 'views/template/home_slider.php'; ?>
    </header>
</div>
<div class="content_wrapper clearfix">
    <div class="sections_group">
        <div class="entry-content">
            <div class="section mcb-section " style="padding-top:0px; padding-bottom:80px; background-color:#f7f7f7; background-image:url(themes/frontend/images/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                <div class="section_wrapper mcb-section-inner">
                    <div class="wrap mcb-wrap three-fourth valign-top clearfix">
                        <div class="mcb-wrap-inner">
                            <div class="column mcb-column one column_placeholder">
                                <div class="placeholder">
                                    &nbsp;
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include APPPATH . 'views/template/home_slider_box.php'; ?>
                    <div class="wrap mcb-wrap divider valign-top clearfix" style="padding:0 7% 0 0">
                        <div class="mcb-wrap-inner"></div>
                    </div>
                    <div class="wrap mcb-wrap one-second valign-top clearfix hide" style="padding:0 6% 0 0">
                        <div class="mcb-wrap-inner">
                            <div class="column mcb-column one column_column">
                                <div class="column_attr clearfix">
                                    <h6 class="themecolor" style="margin-bottom: 5px">My specialization</h6>
                                    <h2>Practise Areas</h2>
                                    <hr class="no_line" style="margin:0 auto 20px">
                                    <p>
                                        <?php echo substr($pa_content, 0, 350) . '...'; ?>
                                    </p>
                                </div>
                            </div>
                            <div class="column mcb-column one column_button">
                                <a class="button button_right button_size_2 button_theme button_js" href="<?php echo $pa_buttonlink; ?>"><span class="button_icon"><i class="icon-right-open-mini"></i></span><span class="button_label"><?php echo $pa_buttontext; ?></span></a>
                            </div>
                        </div>
                    </div>
                    <div class="wrap mcb-wrap one valign-top clearfix" style="padding:40px 0 0">
                        <div class="mcb-wrap-inner">
                            <?php
                            if (isset($home_practiceareas_items) && !empty($home_practiceareas_items)) {
                                $index = 1;
                                foreach ($home_practiceareas_items as $key_pat => $value_pat) {
                                    ?>
                                    <?php if ($index % 3 === 1) { ?>
                                        <div class="column mcb-column one column_divider "><hr class="no_line"></div>
                                    <?php } ?>
                                    <div class="column mcb-column one-third column_column" index1="<?php echo $index; ?>" mod="<?php echo $index % 3; ?>">
                                        <div class="column_attr clearfix" style="padding:0 10% 0 0">
                                            <div class="image_frame image_item no_link scale-with-grid alignnone no_border">
                                                <div class="image_wrapper">
                                                    <img class="scale-with-grid img-pa-items" src="<?php echo $value_pat['pat_icon']; ?>">
                                                </div>
                                            </div>
                                            <hr class="no_line" style="margin:0 auto 20px">
                                            <h5><?php echo $value_pat['pat_header']; ?></h5>
                                            <p>
                                                <?php echo $value_pat['pat_content']; ?>
                                            </p>
                                        </div>
                                    </div>

                                    <?php
                                    $index++;
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section mcb-section" style="padding-top:120px; padding-bottom:200px; background-image:url(<?php echo $tm_bg_image; ?>); background-repeat:no-repeat; background-position:center top">
                <div class="section_wrapper mcb-section-inner">
                    <div class="wrap mcb-wrap one valign-top clearfix">
                        <div class="mcb-wrap-inner">
                            <div class="column mcb-column one column_column">
                                <div class="column_attr clearfix align_center">
                                    <h6 class="themecolor" style="margin-bottom: 5px">Information</h6>
                                    <h2>Testimonials</h2>
                                </div>
                            </div>
                            <?php
                            if (isset($testimonials_details) && !empty($testimonials_details)) {
                                $index = 1;
                                foreach ($testimonials_details as $key_t => $value_t) {
                                    ?>
                                    <div class="column mcb-column one-third column_column">
                                        <div class="column_attr clearfix animate" data-anim-type="fadeInRight">
                                            <div class="image_frame image_item no_link scale-with-grid alignnone no_border">
                                                <div class="image_wrapper">
                                                    <img class="scale-with-grid" src="<?php echo $value_t['ht_image']; ?>">
                                                </div>
                                            </div>
                                            <hr class="no_line" style="margin:0 auto 20px">
                                            <div class="google_font" style="font-family:'Roboto Slab';font-size:72px;line-height:72px;font-weight:400;color:#f2c64d">
                                                <?php echo $value_t['ht_value']; ?>
                                            </div>
                                            <h3><?php echo $value_t['ht_text']; ?></h3>
                                        </div>
                                    </div>
                                    <?php if (($index % 2) == 0) { ?>
                                        <div class="column mcb-column one column_divider">
                                            <hr class="no_line" style="margin:0 auto 40px">
                                        </div>
                                        <?php
                                    }
                                    $index++;
                                }
                            }
                            ?>



                        </div>
                    </div>
                </div>
            </div>
            <div class="section mcb-section" style="padding-top:0px; padding-bottom:80px; background-image:url(themes/frontend/images/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                <div class="section_wrapper mcb-section-inner">
                    <div class="wrap mcb-wrap one valign-top clearfix">
                        <div class="mcb-wrap-inner">
                            <div class="column mcb-column one column_image">
                                <div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
                                    <div class="image_wrapper">
                                        <img class="scale-with-grid" src="themes/frontend/images/home_lawyer_pic9.png">
                                    </div>
                                </div>
                            </div>
                            <div class="column mcb-column one column_divider">
                                <hr class="no_line" style="margin:0 auto 40px">
                            </div>
                            <div class="column mcb-column one column_testimonials ">
                                <div class="testimonials_slider ">
                                    <div class="slider_pager slider_images"></div>
                                    <ul class="testimonials_slider_ul">
                                        <?php
                                        if (isset($testimonial_slider_details) && !empty($testimonial_slider_details)) {
                                            foreach ($testimonial_slider_details as $key_tms => $value_tms) {
                                                ?>
                                                <li>
                                                    <div class="single-photo-img">
                                                        <img src="<?php echo $value_tms['tms_image']; ?>" class="scale-with-grid wp-post-image">
                                                    </div>
                                                    <div class="bq_wrapper">
                                                        <blockquote>
                                                            <?php echo $value_tms['tms_content']; ?>
                                                        </blockquote>
                                                    </div>
                                                    <div class="hr_dots">
                                                        <span></span><span></span><span></span>
                                                    </div>
                                                    <div class="author">
                                                        <h5><?php echo $value_tms['tms_name']; ?></h5><span class="company"></span>
                                                    </div>
                                                </li>
                                                <?php
                                            }
                                        }
                                        ?>

                                    </ul>
                                </div>
                            </div>
                            <div class="column mcb-column one column_button">
                                <div class="button_align align_center">
                                    <a class="button button_right button_size_2 button_theme button_js" href="#"><span class="button_icon"><i class="icon-right-open-mini"></i></span><span class="button_label">Read more</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section mcb-section" style="padding-top:150px; padding-bottom:110px;" data-parallax="3d">
                <img class="mfn-parallax" src="themes/frontend/images/home_lawyer_sectionbg3.jpg" style="opacity:0">
                <div class="section_wrapper mcb-section-inner">
                    <div class="wrap mcb-wrap one valign-top clearfix">
                        <div class="mcb-wrap-inner">
                            <div class="column mcb-column one column_hover_box ">
                                <div class="hover_box">
                                    <a href="#">
                                        <div class="hover_box_wrapper">
                                            <img class="visible_photo scale-with-grid" src="themes/frontend/images/home_lawyer_pic10a.png">
                                            <img class="hidden_photo scale-with-grid" src="themes/frontend/images/home_lawyer_pic10b.png">
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<div id="Wrapper">