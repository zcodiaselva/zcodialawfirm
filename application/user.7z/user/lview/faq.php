
<div id="Header_wrapper">
    <header id="Header">
        <div class="header_placeholder"></div>
          <?php include APPPATH.'views/template/top_menu.php'; ?>
    </header>
</div>
<div id="Content">
    <div class="content_wrapper clearfix">
        <div class="sections_group">
            <div class="entry-content">
                <div class="section mcb-section" style="padding-top:260px; padding-bottom:100px; background-color:#1e1e1e; background-image:url(themes/frontend/images/home_lawyer_sectionbg6.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h1 class="themecolor">Q&amp;A</h1>
                                        <h3 style="color:#fff">Questions and Answers</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px; background-image:url(themes/frontend/images/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one-fourth valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix" style="background-color: #fff; box-shadow: 0 0px 35px rgba(0,0,0,.2)">
                                        <h5 style="background: #f2c64d; color: #fff; padding: 15px 30px; margin: 0">Question Category</h5>
                                        <?php
                                        if (isset($question_category) && !empty($question_category)) {
                                            foreach ($question_category as $key_qc => $value_qc) {
                                                ?>
                                                <a style="display: block; color: #909090; border-bottom: 1px solid #f7f7f7; padding: 15px 30px;" href="#<?php echo str_replace(' ', '-', $value_qc['qc_name']); ?>"><?php echo $value_qc['qc_name']; ?></a>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="wrap mcb-wrap three-fourth valign-top clearfix" style="padding:0 0 0 5%">

                            <div class="mcb-wrap-inner"> 
                                <?php
                                $qd_count = 0;
                                if (isset($question_details) && !empty($question_details)) {
                                    foreach ($question_details as $key_q => $value_q) {
                                        
                                        if (isset($value_q['question_details']) && !empty($value_q['question_details'])){
                                            $qd_count = sizeof($value_q['question_details']);
                                        }
                                      
                                        ?>
                                        <div class="column mcb-column one column_column">
                                            <div class="column_attr clearfix align_center<?php echo $qd_count ===  0 ? ' hide':''; ?>">
                                                <h3 id="<?php echo str_replace(' ', '-', $value_q['qc_name']); ?>"><?php echo $value_q['qc_name']; ?></h3>
                                            </div>
                                        </div>
                                        <div class="column mcb-column one column_faq " >
                                            <div class="faq">
                                                <div class="mfn-acc faq_wrapper  open1st">
                                                    <?php
                                                    $question_no = 1;
                                                    if (isset($value_q['question_details']) && !empty($value_q['question_details'])) {
                                                        foreach ($value_q['question_details'] as $key_qd => $value_qd) {
                                                            ?>
                                                            <div class="question" qc_id="<?php echo $value_qd['qc_id'] ?>" qd_id="<?php echo $value_qd['qd_id'] ?>">
                                                                <div class="title">
                                                                    <span class="num"><?php echo $question_no; ?></span><i class="icon-plus acc-icon-plus"></i><i class="icon-minus acc-icon-minus"></i><?php echo $value_qd['qd_question']; ?>
                                                                </div>
                                                                <div class="answer">
                                                                    <?php echo $value_qd['qd_answer']; ?>
                                                                </div>
                                                            </div>
                                                            <?php
                                                            $question_no += 1;
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px;" data-parallax="3d">
                    <img class="mfn-parallax" src="themes/frontend/images/home_lawyer_sectionbg4.jpg" style="opacity:0">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h2 style="color:#fff">Any questions? Contact with me!</h2>
                                    </div>
                                </div>
                                <div class="column mcb-column one column_button">
                                    <div class="button_align align_center">
                                        <a class="button button_right button_size_2 button_theme button_js" href="contact.html"><span class="button_icon"><i class="icon-right-open-mini"></i></span><span class="button_label">Contact us</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>