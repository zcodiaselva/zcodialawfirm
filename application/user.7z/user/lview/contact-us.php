<div id="Header_wrapper">
    <header id="Header">
        <div class="header_placeholder"></div>
        <?php include APPPATH.'views/template/top_menu.php'; ?>
    </header>
</div>
<div id="Content">
    <div class="content_wrapper clearfix">
        <div class="sections_group">
            <div class="entry-content">
                <div class="section mcb-section" style="padding-top:260px; padding-bottom:100px; background-color:#1e1e1e; background-image:url(themes/frontend/images/home_lawyer_sectionbg6.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h1 class="themecolor">Contact</h1>
                                        <h3 style="color:#fff">Keep in touch</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section highlight-right" style="padding-top:0px; padding-bottom:0px; background-image:url(themes/frontend/images/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one-second valign-top clearfix" style="padding:120px 5% 80px">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix">
                                        <h2>Send us a message</h2>
                                        <hr class="no_line" style="margin:0 auto 20px">
                                        <div id="contactWrapper">
                                            <form id="contactform">
                                                <!-- One Second (1/2) Column -->
                                                <div class="column one-second">
                                                    <input placeholder="Your name" type="text" name="name" id="name" size="40" aria-required="true" aria-invalid="false" />
                                                </div>
                                                <!-- One Second (1/2) Column -->
                                                <div class="column one-second">
                                                    <input placeholder="Your e-mail" type="email" name="email" id="email" size="40" aria-required="true" aria-invalid="false" />
                                                </div>
                                                <div class="column one">
                                                    <input placeholder="Subject" type="text" name="subject" id="subject" size="40" aria-invalid="false" />
                                                </div>
                                                <div class="column one">
                                                    <textarea placeholder="Message" name="body" id="body" style="width:100%;" rows="10" aria-invalid="false"></textarea>
                                                </div>
                                                <div class="column one">
                                                    <input type="button" value="Send A Message" id="submit" onClick="return check_values()">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wrap mcb-wrap one-second valign-top clearfix" style="padding:120px 5% 80px">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix">
                                        <h2>Lorem ipsum dolar sit</h2>
                                        <hr class="no_line" style="margin:0 auto 20px">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.
                                        </p>
                                    </div>
                                </div>
                                <div class="column mcb-column one-second column_column">
                                    <div class="column_attr clearfix">
                                        <div class="image_frame image_item no_link scale-with-grid alignnone no_border">
                                            <div class="image_wrapper">
                                                <img class="scale-with-grid" src="themes/frontend/images/home_lawyer_pic11.png">
                                            </div>
                                        </div>
                                        <hr class="no_line" style="margin:0 auto 20px">
                                        <h4 style="color: #f2c64d">Address</h4>
                                        <p>
                                            Level 13, 2 Elizabeth St,
                                            <br> Melbourne, Victoria 3000,
                                            <br> Australia
                                        </p>
                                    </div>
                                </div>
                                <div class="column mcb-column one-second column_column">
                                    <div class="column_attr clearfix">
                                        <div class="image_frame image_item no_link scale-with-grid alignnone no_border">
                                            <div class="image_wrapper">
                                                <img class="scale-with-grid" src="themes/frontend/images/home_lawyer_pic12.png">
                                            </div>
                                        </div>
                                        <hr class="no_line" style="margin:0 auto 20px">
                                        <h4>Contact us</h4>
                                        <p>
                                            <a style="color: #5f5f5f;" href="#"><span>noreply@envato.com</span></a>
                                            <br> +61 (0) 3 8376 6284
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section no-margin-h no-margin-v full-width" style="padding-top:0px; padding-bottom:0px">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_map ">
                                    <div class="google-map-wrapper no_border">
                                        <div class="google-map" id="google-map-area-5a94032296ccc" style="width:100%; height:550px">
                                            &nbsp;
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
