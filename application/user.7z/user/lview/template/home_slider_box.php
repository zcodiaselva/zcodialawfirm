<div class="wrap mcb-wrap one-fourth valign-top move-up clearfix" style="margin-top:-240px" data-mobile="no-up">
    <div class="mcb-wrap-inner">
        <div class="column mcb-column one column_column">
            <div class="column_attr clearfix align_center" style="background-color:#292929; padding:50px 35px">
                <div class="google_font" style="font-family:'Roboto Slab';font-size:72px;line-height:72px;font-weight:400;color:#f2c64d">
                    <?php echo $hsb_text1; ?>
                </div>
                <h3 style="color:#fff"><?php echo $hsb_text2; ?>
                </h3>
                <hr class="no_line" style="margin:0 auto 10px">
                <a href="<?php echo $hsb_buttonLink; ?>">
                    <div class="image_frame image_item no_link scale-with-grid no_border">
                        <div class="image_wrapper">
                            <img class="scale-with-grid" src="<?php echo $hsb_buttonImage; ?>">
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>