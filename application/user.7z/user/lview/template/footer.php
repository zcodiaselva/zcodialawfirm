
</div>
<footer id="Footer" class="clearfix">
    <div class="widgets_wrapper" style="padding:70px 0">
        <div class="container">
            <?php
            $contact_name = '';
            if (isset($contactus_address) && !empty($contactus_address)) {
                foreach ($contactus_address as $key_contact => $value_contact) {
                    $contact_name = $value_contact['c_name'];
                    if (isset($contact_name) && !empty($contact_name)) {
                        ?>
                        <div class="column one-fourth">
                            <aside class="widget_text widget widget_custom_html">
                                <div class="textwidget custom-html-widget">
                                    <div class="image_frame image_item no_link scale-with-grid alignnone no_border">
                                        <div class="image_wrapper">
                                            <img class="scale-with-grid" src="<?php echo $value_contact['c_icon']; ?>">
                                        </div>
                                    </div>
                                    <hr class="no_line" style="margin:0 auto 20px">
                                    <h4 style="color: #f2c64d"><?php echo $value_contact['c_name']; ?></h4>
                                    <p>
                                        <?php echo $value_contact['c_content']; ?>
                                    </p>
                                </div>
                            </aside>
                        </div>
                        <?php
                    }
                }
            }
            ?>

            <div class="column one-fourth here">
                <aside class="widget_text widget widget_custom_html">
                    <div class="textwidget custom-html-widget">
                        <hr class="no_line" style="margin: 0 auto 54px">
                        <p style="font-size:28px;line-height:28px">
                            <?php
                            $social_link = '';
                            if (isset($contactus_social) && !empty($contactus_social)) {

                                $index1 = 0;
                                foreach ($contactus_social as $key_social => $value_social) {
                                    ?>
                                
                                <a about="_blank" href="<?php echo 'https://' . str_replace(array('icon-', '-circled'), '', $value_social['c_social_name']) . '.com/'; ?><?php echo ($value_social['c_social_link'] == '#' ? 'javascript:void(0);' : $value_social['c_social_link']); ?>"><i class="<?php echo $value_social['c_social_name']; ?>"></i></a>
                                <?php
                            }
                        }
                        ?>
                        </p>
                    </div>
                </aside>
            </div>
        </div>
    </div>
    <div class="footer_copy">
        <div class="container">
            <div class="column one">
                <div class="copyright">
                    <?php
                    if (isset($contactus_footer) && !empty($contactus_footer)) {
                        foreach ($contactus_footer as $key_footer => $value_footer) {
                            echo $value_footer['c_footer_content'];
                        }
                    }
                    ?></div>
            </div>
        </div>
    </div>
</footer>
</div>

<!-- side menu -->
<div id="Side_slide" class="right dark" data-width="250">
    <div class="close-wrapper">
        <a href="#" class="close"><i class="icon-cancel-fine"></i></a>
    </div>
    <div class="menu_wrapper"></div>
</div>
<div id="body_overlay"></div>

<!-- JS -->
<script src="themes/frontend/js/jquery-2.1.4.min.js"></script>

<script src="themes/frontend/js/mfn.menu.js"></script>
<script src="themes/frontend/js/jquery.plugins.js"></script>
<script src="themes/frontend/js/jquery.jplayer.min.js"></script>
<script src="themes/frontend/js/animations/animations.js"></script>
<script src="themes/frontend/js/translate3d.js"></script>
<script src="themes/frontend/js/scripts.js"></script>

<script src="themes/frontend/plugins/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.video.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.actions.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.migration.min.js"></script>
<script src="themes/frontend/plugins/rs-plugin/js/extensions/revolution.extension.parallax.min.js"></script>

<!--<script src="http://maps.google.com/maps/api/js?sensor=false&amp;ver=5.9"></script>-->
<script type='text/javascript' src='http://maps.googleapis.com/maps/api/js?key=AIzaSyAidINa74sv7bt7Y3vqjKjM7m0PgJN1bhk&amp;ver=4.9.4'>
</script>

<script type="text/javascript">
    /*<![CDATA[*/
    function setREVStartSize(e) {
        try {
            var i = jQuery(window).width(),
                    t = 9999,
                    r = 0,
                    n = 0,
                    l = 0,
                    f = 0,
                    s = 0,
                    h = 0;
            if (e.responsiveLevels && (jQuery.each(e.responsiveLevels, function (e, f) {
                f > i && (t = r = f, l = e), i > f && f > r && (r = f, n = e)
            }), t > r && (l = n)), f = e.gridheight[l] || e.gridheight[0] || e.gridheight, s = e.gridwidth[l] || e.gridwidth[0] || e.gridwidth, h = i / s, h = h > 1 ? 1 : h, f = Math.round(h * f), "fullscreen" == e.sliderLayout) {
                var u = (e.c.width(), jQuery(window).height());
                if (void 0 != e.fullScreenOffsetContainer) {
                    var c = e.fullScreenOffsetContainer.split(",");
                    if (c)
                        jQuery.each(c, function (e, i) {
                            u = jQuery(i).length > 0 ? u - jQuery(i).outerHeight(!0) : u
                        }), e.fullScreenOffset.split("%").length > 1 && void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 ? u -= jQuery(window).height() * parseInt(e.fullScreenOffset, 0) / 100 : void 0 != e.fullScreenOffset && e.fullScreenOffset.length > 0 && (u -= parseInt(e.fullScreenOffset, 0))
                }
                f = u
            } else
                void 0 != e.minHeight && f < e.minHeight && (f = e.minHeight);
            e.c.closest(".rev_slider_wrapper").css({
                height: f
            })
        } catch (d) {
            console.log("Failure at Presize of Slider:" + d)
        }
    }
    ; /*]]>*/
</script>
<script type="text/javascript">
    setREVStartSize({
        c: jQuery('#rev_slider_1_1'),
        gridwidth: [1176],
        gridheight: [750],
        sliderLayout: 'auto'
    });
    var revapi1, tpj = jQuery;
    tpj.noConflict();
    tpj(document).ready(function () {
        if (tpj("#rev_slider_1_1").revolution == undefined) {
            revslider_showDoubleJqueryError("#rev_slider_1_1");
        } else {
            revapi1 = tpj("#rev_slider_1_1").show().revolution({
                sliderType: "standard",
                //jsFileLocation: "//themes.muffingroup.com/be/cleaner/wp-content/plugins/revslider/public/assets/js/",
                jsFileLocation: "//localhost:8080/lawyer/themes/frontend/plugins/rs-plugin/js/",
                sliderLayout: "auto",
                dottedOverlay: "none",
                delay: 5000,
                navigation: {
                    keyboardNavigation: "off",
                    keyboard_direction: "horizontal",
                    mouseScrollNavigation: "off",
                    mouseScrollReverse: "default",
                    onHoverStop: "on",
                    touch: {
                        touchenabled: "on",
                        touchOnDesktop: "off",
                        swipe_threshold: 75,
                        swipe_min_touches: 1,
                        swipe_direction: "horizontal",
                        drag_block_vertical: false
                    },
                    arrows: {
                        style: "uranus",
                        enable: true,
                        hide_onmobile: false,
                        hide_onleave: false,
                        tmp: '',
                        left: {
                            h_align: "left",
                            v_align: "bottom",
                            h_offset: 40,
                            v_offset: 40
                        },
                        right: {
                            h_align: "right",
                            v_align: "bottom",
                            h_offset: 40,
                            v_offset: 40
                        }
                    }
                },
                visibilityLevels: [1240, 1024, 778, 480],
                gridwidth: 1176,
                gridheight: 750,
                lazyType: "none",
                shadow: 0,
                spinner: "spinner2",
                stopLoop: "off",
                stopAfterLoops: -1,
                stopAtSlide: -1,
                shuffle: "off",
                autoHeight: "off",
                disableProgressBar: "on",
                hideThumbsOnMobile: "off",
                hideSliderAtLimit: 0,
                hideCaptionAtLimit: 0,
                hideAllCaptionAtLilmit: 0,
                debugMode: false,
                fallbacks: {
                    simplifyAll: "off",
                    nextSlideOnWindowFocus: "off",
                    disableFocusListener: false,
                }
            });
        }
    });
</script>
<script>
    /*<![CDATA[*/
//    var htmlDivCss = ' #rev_slider_1_1_wrapper .tp-loader.spinner2{ background-color: #FFFFFF !important; } ';
//    var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
//    if (htmlDiv) {
//        htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
//    } else {
//        var htmlDiv = document.createElement('div');
//        htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
//        document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
//    } /*]]>*/
</script>
<script>
    /*<![CDATA[*/
//    var htmlDivCss = unescape("%23rev_slider_1_1%20.uranus.tparrows%20%7B%20width%3A50px%3B%20height%3A50px%3B%20margin-top%3A-150px%3B%20background%3Argba%28255%2C255%2C255%2C0%29%3B%20%7D%23rev_slider_1_1%20.uranus.tparrows%3Abefore%20%7B%20width%3A50px%3B%20height%3A50px%3B%20line-height%3A50px%3B%20font-size%3A40px%3B%20transition%3Aall%200.3s%3B%20-webkit-transition%3Aall%200.3s%3B%20%7D%23rev_slider_1_1%20.uranus.tparrows%3Ahover%3Abefore%20%7B%20opacity%3A0.75%3B%20%7D%23rev_slider_1_1%20.uranus.tparrows%20%7B%20width%3A50px%3B%20height%3A50px%3B%20margin-top%3A-150px%3B%20background%3Argba%28255%2C255%2C255%2C0%29%3B%20%7D%23rev_slider_1_1%20.uranus.tparrows%3Abefore%20%7B%20width%3A50px%3B%20height%3A50px%3B%20line-height%3A50px%3B%20font-size%3A40px%3B%20transition%3Aall%200.3s%3B%20-webkit-transition%3Aall%200.3s%3B%20%7D%23rev_slider_1_1%20.uranus.tparrows%3Ahover%3Abefore%20%7B%20opacity%3A0.75%3B%20%7D");
//    var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
//    if (htmlDiv) {
//        htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
//        console.log(htmlDiv.InnerHTML);
//    } else {
//        var htmlDiv = document.createElement('div');
//        htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
//        document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
//    } /*]]>*/
</script>
<script>
    function google_maps_5a94032296ccc() {
        var latlng = new google.maps.LatLng(-33.8710, 151.2039);
        var draggable = true;
        var myOptions = {
            zoom: 13,
            center: latlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            styles: [{
                    "featureType": "water",
                    "elementType": "geometry",
                    "stylers": [{
                            "color": "#e9e9e9"
                        }, {
                            "lightness": 17
                        }]
                }, {
                    "featureType": "landscape",
                    "elementType": "geometry",
                    "stylers": [{
                            "color": "#f5f5f5"
                        }, {
                            "lightness": 20
                        }]
                }, {
                    "featureType": "road.highway",
                    "elementType": "geometry.fill",
                    "stylers": [{
                            "color": "#ffffff"
                        }, {
                            "lightness": 17
                        }]
                }, {
                    "featureType": "road.highway",
                    "elementType": "geometry.stroke",
                    "stylers": [{
                            "color": "#ffffff"
                        }, {
                            "lightness": 29
                        }, {
                            "weight": 0.2
                        }]
                }, {
                    "featureType": "road.arterial",
                    "elementType": "geometry",
                    "stylers": [{
                            "color": "#ffffff"
                        }, {
                            "lightness": 18
                        }]
                }, {
                    "featureType": "road.local",
                    "elementType": "geometry",
                    "stylers": [{
                            "color": "#ffffff"
                        }, {
                            "lightness": 16
                        }]
                }, {
                    "featureType": "poi",
                    "elementType": "geometry",
                    "stylers": [{
                            "color": "#f5f5f5"
                        }, {
                            "lightness": 21
                        }]
                }, {
                    "featureType": "poi.park",
                    "elementType": "geometry",
                    "stylers": [{
                            "color": "#dedede"
                        }, {
                            "lightness": 21
                        }]
                }, {
                    "elementType": "labels.text.stroke",
                    "stylers": [{
                            "visibility": "on"
                        }, {
                            "color": "#ffffff"
                        }, {
                            "lightness": 16
                        }]
                }, {
                    "elementType": "labels.text.fill",
                    "stylers": [{
                            "saturation": 36
                        }, {
                            "color": "#333333"
                        }, {
                            "lightness": 40
                        }]
                }, {
                    "elementType": "labels.icon",
                    "stylers": [{
                            "visibility": "off"
                        }]
                }, {
                    "featureType": "transit",
                    "elementType": "geometry",
                    "stylers": [{
                            "color": "#f2f2f2"
                        }, {
                            "lightness": 19
                        }]
                }, {
                    "featureType": "administrative",
                    "elementType": "geometry.fill",
                    "stylers": [{
                            "color": "#fefefe"
                        }, {
                            "lightness": 20
                        }]
                }, {
                    "featureType": "administrative",
                    "elementType": "geometry.stroke",
                    "stylers": [{
                            "color": "#fefefe"
                        }, {
                            "lightness": 17
                        }, {
                            "weight": 1.2
                        }]
                }],
            draggable: draggable,
            zoomControl: true,
            mapTypeControl: false,
            streetViewControl: false,
            scrollwheel: false
        };
        var map = new google.maps.Map(document.getElementById("google-map-area-5a94032296ccc"), myOptions);
        var marker = new google.maps.Marker({
            position: latlng,
            // icon: "images/home_lawyer_contact1.png",
            map: map
        });
    }
    function geturisegment() {
        var pathArray = window.location.pathname.split('/');
        return pathArray[2];
    }

    jQuery(document).ready(function ($) {

        //   google_maps_5a94032296ccc();
        // alert(geturisegment())
    });
</script>
<script>
    includeHTML();
</script>
</body>



</html>