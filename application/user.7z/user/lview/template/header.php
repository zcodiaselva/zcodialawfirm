<!DOCTYPE html>

<html class="no-js">
    <head>
        <title>Be</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Favicons -->
        <link rel="shortcut icon" href="themes/frontend/images/favicon.ico">

        <!-- FONTS -->
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:100,300,400,400italic,700'>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Patua+One:100,300,400,400italic,700'>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Lato:100,300,400,400italic,500,700,700italic'>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,400italic,500,700,700italic'>

        <!-- CSS -->
        <link rel='stylesheet' href='themes/frontend/css/global/global.css'>

        <link rel='stylesheet' href='themes/frontend/css/structure.css'>
        <link rel='stylesheet' href='themes/frontend/css/lawyer3.css'>
        <link rel='stylesheet' href='themes/frontend/css/custom.css'>

        <!-- Revolution Slider -->
        <link rel="stylesheet" href="themes/frontend/plugins/rs-plugin/css/settings.css">

        <link rel='stylesheet' href='themes/frontend/css/global/style-demo.css'>
        <script>
            function includeHTML() {
                var z, i, elmnt, file, xhttp;
                /*loop through a collection of all HTML elements:*/
                z = document.getElementsByTagName("*");
                for (i = 0; i < z.length; i++) {
                    elmnt = z[i];
                    /*search for elements with a certain atrribute:*/
                    file = elmnt.getAttribute("w3-include-html");
                    console.log('file:'+file);
                    if (file) {
                        
                        /*make an HTTP request using the attribute value as the file name:*/
                        xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function () {
                            if (this.readyState == 4) {
                                if (this.status == 200) {
                                    elmnt.innerHTML = this.responseText;
                                }
                                if (this.status == 404) {
                                    elmnt.innerHTML = "Page not found.";
                                }
                                /*remove the attribute, and call this function once more:*/
                                elmnt.removeAttribute("w3-include-html");
                                includeHTML();
                            }
                        }
                        xhttp.open("GET", file, true);
                        xhttp.send();
                        /*exit the function:*/
                        return;
                    }
                }
            }
            ;
        </script>
    </head>
    <body class="color-custom style-simple button-stroke layout-full-width no-content-padding header-transparent minimalist-header-no sticky-header sticky-tb-color ab-hide subheader-both-center menu-link-color menuo-right menuo-no-borders footer-copy-center mobile-tb-center mobile-side-slide mobile-mini-mr-ll tablet-sticky mobile-header-mini mobile-sticky be-reg-2085">
        <div id="Wrapper">
