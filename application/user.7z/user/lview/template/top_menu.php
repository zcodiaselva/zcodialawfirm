<div id="Top_bar">
            <div class="container">
                <div class="column one">
                    <div class="top_bar_left clearfix">
                        <div class="logo">
                            <a id="logo" href="index.html" title="BeLawyer3 - BeTheme" data-height="60" data-padding="30">
                                <img class="logo-main scale-with-grid" src="themes/frontend/images/lawyer.png" data-retina="themes/frontend/images/retina-lawyer.png" data-height="58" alt="lawyer">
                                <img class="logo-sticky scale-with-grid" src="themes/frontend/images/lawyer.png" data-retina="themes/frontend/images/retina-lawyer.png" data-height="58" alt="lawyer">
                                <img class="logo-mobile scale-with-grid" src="themes/frontend/images/lawyer.png" data-retina="themes/frontend/images/retina-lawyer.png" data-height="58" alt="lawyer">
                                <img class="logo-mobile-sticky scale-with-grid" src="themes/frontend/images/lawyer.png" data-retina="themes/frontend/images/retina-lawyer.png" data-height="58" alt="lawyer"></a>
                        </div>
                        <div class="menu_wrapper">
                            <nav id="menu">
                                <ul id="menu-main-menu" class="menu menu-main">
                                    <li class="<?php echo ($this->uri->segment(1) == ''? 'current-menu-item': ''); ?>">
                                        <a href="./"><span>Home</span></a>
                                    </li>
                                    <li class="<?php echo ($this->uri->segment(1) == 'AboutUs'? 'current-menu-item': ''); ?>">
                                        <a href="AboutUs"><span>About</span></a>
                                    </li>
                                    <li class="<?php echo ($this->uri->segment(1) == 'PracticeAreas'? 'current-menu-item': ''); ?>">
                                        <a href="PracticeAreas"><span>Practice Areas</span></a>
                                    </li>
                                    <li class="<?php echo ($this->uri->segment(1) == 'FAQ'? 'current-menu-item': ''); ?>">
                                        <a href="FAQ"><span>Q&#038;A</span></a>
                                    </li>
                                    <li class="<?php echo ($this->uri->segment(1) == 'ContactUs'? 'current-menu-item': ''); ?>">
                                        <a href="ContactUs"><span>Contact</span></a>
                                    </li>
                                </ul>
                            </nav>
                            <a class="responsive-menu-toggle" href="#"><i class="icon-menu-fine"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
