
<div class="mfn-main-slider" id="mfn-rev-slider">
            <div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery" style="margin:0px auto;background:transparent;padding:0px;margin-top:0px;margin-bottom:0px">
                <div id="rev_slider_1_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.7">
                    <ul>
                        <?php
                        if (isset($home_slider_details) && !empty($home_slider_details)) {
                            $index = 1;
                            foreach ($home_slider_details as $key => $value) {
                                ?>

                                <li data-index="rs-<?php echo $index; ?>" data-transition="fade" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off" data-title="Slide"
                                    data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <img src="<?php echo ($value['hs_bgimage'] == ''?'themes/frontend/images/transparent_image.png':$value['hs_bgimage']); ?>" title="home_lawyer_slider_bg" width="1920" height="860" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                                    <div class="tp-caption tp-resizeme" id="slide-1-layer-1" data-x="50" data-y="350" data-width="['auto']" data-height="['auto']" data-type="text" data-responsive_offset="on" data-frames='[{"delay":100,"speed":900,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                         data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 5; white-space: nowrap; font-size: 72px; line-height: 72px; font-weight: 400; color: #f2c64d; letter-spacing: 0px;font-family:Roboto Slab">
                                             <?php echo $value['hs_header1']; ?>
                                    </div>
                                    <div class="tp-caption   tp-resizeme" id="slide-1-layer-2" data-x="50" data-y="450" data-width="['auto']" data-height="['auto']" data-type="text" data-responsive_offset="on" data-frames='[{"delay":200,"speed":900,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                         data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 6; white-space: nowrap; font-size: 30px; line-height: 40px; font-weight: 400; color: #fff; letter-spacing: 0px;font-family:Roboto Slab">
                                             <?php echo $value['hs_subheader1']; ?>
                                        <br> <?php echo $value['hs_subheader2']; ?>
                                    </div>
                                    <a class="tp-caption rev-btn " href="<?php echo $value['hs_buttonlink1']; ?>" target="_self" id="slide-1-layer-3" data-x="50" data-y="600" data-width="['auto']" data-height="['auto']" data-type="button" data-actions='' data-responsive_offset="on" data-responsive="off"
                                       data-frames='[{"delay":300,"speed":900,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(255,255,255);bg:rgb(242,198,77);"}]'
                                       data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[15,15,15,15]" data-paddingright="[35,35,35,35]" data-paddingbottom="[15,15,15,15]" data-paddingleft="[35,35,35,35]" style="z-index: 7; white-space: nowrap; font-size: 16px; line-height: 16px; font-weight: 700; color: #f2c64d; letter-spacing: px;font-family:Roboto Slab;background-color:rgba(0,0,0,0);border-color:rgb(242,198,77);border-style:solid;border-width:1px 1px 1px 1px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;text-decoration: none"><?php echo $value['hs_buttontext1']; ?><i style="margin-left: 20px;" class="icon-right-open-mini"></i> </a>
                                    <div class="tp-caption   tp-resizeme" id="slide-1-layer-4" data-x="center" data-hoffset="435" data-y="center" data-voffset="-69" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-type="image" data-responsive_offset="on"
                                         data-frames='[{"delay":400,"speed":900,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]' data-textAlign="['inherit','inherit','inherit','inherit']"
                                         data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 8"><img src="<?php echo ($value['hs_signature'] == ''?'themes/frontend/images/transparent_image.png':$value['hs_signature']); ?>" data-ww="143px" data-hh="82px" width="143" height="82" data-no-retina>
                                    </div>
                                </li>
                                <?php
                                $index++;
                            }
                        }
                        ?>
                    </ul>
                </div>

            </div>
        </div>