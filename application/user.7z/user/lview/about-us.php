<?php
$about_myself = $aboutus[0];


$about_timeline = $abt_timeline[0];
$auHeaderTitle = $auHeaderSubtitle = $auContentMainTitle = $auContentSubTitle = $auContent = $auContentImage = $auSliderImage = '';
if (isset($aboutus) && !empty($aboutus)) {
    $auHeaderTitle = $aboutus[0]['au_header_title'];
    $auHeaderSubtitle = $aboutus[0]['au_header_subtitle'];
    $auContentMainTitle = $aboutus[0]['au_content_main_title'];
    $auContentSubTitle = $aboutus[0]['au_content_sub_title'];
    $auContent = $aboutus[0]['au_content'];
    $auContentImage = $aboutus[0]['au_content_image'];
    $auSliderImage = $aboutus[0]['au_slider_image'];
}
$path = APPPATH . 'views/template/top_menu.php';
?>
<div id="Header_wrapper">
    <header id="Header">
        <div class="header_placeholder"></div>
        <?php include APPPATH . 'views/template/top_menu.php'; ?>
    </header>
</div>
<div id="Content">
    <div class="content_wrapper clearfix">
        <div class="sections_group">
            <div class="entry-content">
                <div class="section mcb-section" style="padding-top:260px; padding-bottom:100px; background-color:#1e1e1e; background-image:url(<?php echo $auSliderImage; ?>); background-position:center center;background-size:cover;">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h1 class="themecolor"><?php echo $auHeaderTitle; ?></h1>
                                        <h3 style="color:#fff"><?php echo $auHeaderSubtitle ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px; background-color:#f7f7f7; background-image:url(http://betheme.muffingroupsc.netdna-cdn.com/be/lawyer3/wp-content/uploads/2018/02/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one-second column_column">
                                    <div class="column_attr clearfix" style="padding:0 10% 0 0">
                                        <h6 class="themecolor" style="margin-bottom: 5px"><?php echo $auContentMainTitle; ?></h6>
                                        <h2><?php echo $auContentSubTitle; ?></h2>
                                        <hr class="no_line" style="margin:0 auto 20px">
                                        <p>
                                            <?php echo $auContent; ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="column mcb-column one-second column_image">
                                    <div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
                                        <div class="image_wrapper">
                                            <img class="scale-with-grid" src="<?php echo $auContentImage; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="column mcb-column one column_divider">
                                    <hr class="no_line" style="margin:0 auto 40px">
                                </div>
                                <?php
                                $index = 1;
                                if (isset($aboutus_items) && !empty($aboutus_items)) {
                                    foreach ($aboutus_items as $key_aui => $value_aui) {
                                        ?>
                                        <div class="column mcb-column one-fourth column_column">
                                            <div class="column_attr clearfix" style="padding:0 5% 0 0">
                                                <div class="image_frame image_item no_link scale-with-grid alignnone no_border">
                                                    <div class="image_wrapper">
                                                        <img class="scale-with-grid" src="<?php echo $value_aui['auti_image']; ?>">
                                                    </div>
                                                </div>
                                                <hr class="no_line" style="margin:0 auto 20px">
                                                <h5><?php echo $value_aui['auti_name']; ?></h5>
                                                <p>
                                                    <?php echo $value_aui['auti_content']; ?>
                                                </p>
                                            </div>
                                        </div>
                                        <?php if (($index % 4) == 0) { ?>
                                            <div class="column mcb-column one column_divider">
                                                <hr class="no_line" style="margin:0 auto 40px">
                                            </div>
                                        <?php } ?>
                                        <?php
                                        $index++;
                                    }
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px; background-image:url(themes/frontend/images/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h6 class="themecolor" style="margin-bottom: 5px"><?php echo $about_timeline['aut_main_title']; ?></h6>
                                        <h2><?php echo $about_timeline['aut_sub_title']; ?></h2>
                                    </div>
                                </div>
                                <div class="column mcb-column one column_timeline ">
                                    <ul class="timeline_items">
                                        <?php foreach ($abt_timelineitems as $tl_key => $tl_value) { ?>
                                            <li>
                                                <h3><span><?php echo $abt_timelineitems[$tl_key]['autli_fromyear'] . ' - ' . $abt_timelineitems[$tl_key]['autli_toyear']; ?></span> <?php echo $abt_timelineitems[$tl_key]['autli_head']; ?></h3>
                                                <div class="desc">
                                                    <?php echo $abt_timelineitems[$tl_key]['autli_content']; ?>
                                                </div>
                                            </li>
                                        <?php } ?>
                                        <!--li>
                                            <h3><span>2004 - 2005</span> Nulla imperdiet sit amet</h3>
                                            <div class="desc">
                                                Nullam wisi ultricies a, gravida vitae, dapibus risus ante sodales lectus blandit eu, tempor diam pede cursus vitae, ultricies eu, faucibus quis.
                                            </div>
                                        </li>
                                        <li>
                                            <h3><span>2005 - 2006</span> Quisque lorem tortor fringilla sed</h3>
                                            <div class="desc">
                                                Aliquam sem. In hendrerit nulla quam nunc, accumsan congue. Lorem ipsum primis in nibh vel risus. Sed vel lectus. Ut sagittis, ipsum dolor quam.
                                            </div>
                                        </li>
                                        <li>
                                            <h3><span>2006 - Today</span> Cursus et porttitor risus</h3>
                                            <div class="desc">
                                                Curabitur et ligula. Ut molestie a, ultricies porta urna. Vestibulum commodo volutpat a, convallis ac, laoreet enim. Phasellus fermentum in, dolor.
                                            </div>
                                        </li-->
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px;" data-parallax="3d"><img class="mfn-parallax" src="themes/frontend/images/home_lawyer_sectionbg4.jpg" style="opacity:0">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h2 style="color:#fff">Any questions? Contact with me!</h2>
                                    </div>
                                </div>
                                <div class="column mcb-column one column_button">
                                    <div class="button_align align_center">
                                        <a class="button button_right button_size_2 button_theme button_js" href="contact.html"><span class="button_icon"><i class="icon-right-open-mini"></i></span><span class="button_label">Contact us</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

