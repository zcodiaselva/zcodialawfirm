<?php
$pa_header = $pa_subheader = $pa_content = $pa_image = $pa_sideimage = $pa_buttontext = $pa_buttonlink = '';
if (isset($about_pa) && !empty($about_pa)) {
    $pa_header = $about_pa[0]['pa_mainheader'];
    $pa_subheader = $about_pa[0]['pa_subheader'];
    $pa_content = $about_pa[0]['pa_content'];
    $pa_image = $about_pa[0]['pa_image'];
    $pa_sideimage = $about_pa[0]['pa_sideimage'];
    $pa_buttontext = $about_pa[0]['pa_buttontext'];
    $pa_buttonlink = $about_pa[0]['pa_buttonlink'];
}
?>
<div id="Header_wrapper">
    <header id="Header">
        <div class="header_placeholder"></div>
          <?php include APPPATH.'views/template/top_menu.php'; ?>
    </header>
</div>
<div id="Content">
    <div class="content_wrapper clearfix">
        <div class="sections_group">
            <div class="entry-content">
                <div class="section mcb-section" style="padding-top:260px; padding-bottom:100px; background-color:#1e1e1e; background-image:url(themes/frontend/images/home_lawyer_sectionbg6.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h1 class="themecolor">Pratice Areas</h1>
                                        <h3 style="color:#fff">What I'm doing</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px; background-color:#f7f7f7; background-image:url(themes/frontend/images/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one-second valign-top clearfix" style="padding:0 5% 0 0">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix">
                                        <h6 class="themecolor" style="margin-bottom: 5px"><?php echo $pa_header; ?></h6>
                                        <h2><?php echo $pa_subheader; ?></h2>
                                        <hr class="no_line" style="margin:0 auto 20px">
                                        <p>
                                            <?php echo $pa_content; ?>
                                        </p>
                                        <hr class="no_line" style="margin:0 auto 10px">

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wrap mcb-wrap one-second valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_image">
                                    <div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
                                        <div class="image_wrapper">
                                            <img class="scale-with-grid" src="<?php echo $pa_image; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_divider">
                                    <hr class="no_line" style="margin:0 auto 50px">
                                </div>
                            </div>
                        </div>
                        <div class="wrap mcb-wrap one-second valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_image">
                                    <div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
                                        <div class="image_wrapper">
                                            <img class="scale-with-grid" src="<?php echo $pa_sideimage; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wrap mcb-wrap one-second valign-top clearfix" style="padding:0 0 0 5%">
                            <div class="mcb-wrap-inner"><?php
                                if (isset($practiceareas_items) && !empty($practiceareas_items)) {
                                    //$index = 0;
                                    foreach ($practiceareas_items as $key_pat => $value_pat) {
                                        ?>
                                        <div class="column mcb-column one-second column_column">
                                            <div class="column_attr clearfix" style="padding:0 10% 0 0">
                                                <div class="image_frame image_item no_link scale-with-grid alignnone no_border">
                                                    <div class="image_wrapper">
                                                        <img class="scale-with-grid" src="<?php echo $value_pat['pat_icon']; ?>">
                                                    </div>
                                                </div>
                                                <hr class="no_line" style="margin:0 auto 20px">
                                                <h5><?php echo $value_pat['pat_header']; ?></h5>
                                                <p>
                                                    <?php echo $value_pat['pat_content']; ?>
                                                </p>
                                            </div>
                                        </div>

                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px; background-image:url(themes/frontend/images/home_lawyer_sectionbg1.png); background-repeat:repeat-y; background-position:center top">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_testimonials ">
                                    <div class="testimonials_slider ">
                                        <div class="slider_pager slider_images"></div>
                                        <ul class="testimonials_slider_ul">
                                            <?php
                                            if (isset($testimonial_slider_details) && !empty($testimonial_slider_details)) {
                                                foreach ($testimonial_slider_details as $key_tms => $value_tms) {
                                                    ?>
                                                    <li>
                                                        <div class="single-photo-img">
                                                            <img src="<?php echo $value_tms['tms_image']; ?>" class="scale-with-grid wp-post-image">
                                                        </div>
                                                        <div class="bq_wrapper">
                                                            <blockquote>
                                                                <?php echo $value_tms['tms_content']; ?>
                                                            </blockquote>
                                                        </div>
                                                        <div class="hr_dots">
                                                            <span></span><span></span><span></span>
                                                        </div>
                                                        <div class="author">
                                                            <h5><?php echo $value_tms['tms_name']; ?></h5><span class="company"></span>
                                                        </div>
                                                    </li>
                                                    <?php
                                                }
                                            }
                                            ?>

                                        </ul>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="section mcb-section" style="padding-top:120px; padding-bottom:80px;" data-parallax="3d"><img class="mfn-parallax" src="themes/frontend/images/home_lawyer_sectionbg4.jpg" style="opacity:0">
                    <div class="section_wrapper mcb-section-inner">
                        <div class="wrap mcb-wrap one valign-top clearfix">
                            <div class="mcb-wrap-inner">
                                <div class="column mcb-column one column_column">
                                    <div class="column_attr clearfix align_center">
                                        <h2 style="color:#fff">Any questions? Contact with me!</h2>
                                    </div>
                                </div>
                                <div class="column mcb-column one column_button">
                                    <div class="button_align align_center">
                                        <a class="button button_right button_size_2 button_theme button_js" href="contact.html"><span class="button_icon"><i class="icon-right-open-mini"></i></span><span class="button_label">Contact us</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>