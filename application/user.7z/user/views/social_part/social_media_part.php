<!-- Social-media Part Start -->
<section class="social-media-part section-p">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-7">
                <div class="section-head-2">
                    <h2>Read Our Expertly Written Blog or Follow Us on <span class="white">Social Media</span></h2>
                    <p class="white">Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim.</p>
                    <a href="#" class="btn-1 bg-brand-color">CONTACT US <i class="fa fa-long-arrow-right"></i></a>
                </div>
                <div class="achivement-blog">
                    <ul class="flat-list">
                        <li>
                            <i class="fa fa-facebook"></i>
                            <h6>Facebook</h6>
                            <span class="counter">12546</span>
                        </li>
                        <li>
                            <i class="fa fa-twitter"></i>
                            <h6>Twiter</h6>
                            <span class="counter">12546</span>
                        </li>
                        <li>
                            <i class="fa fa-pinterest"></i>
                            <h6>Pinterest</h6>
                            <span class="counter">12546</span>
                        </li>
                        <li>
                            <i class="fa fa-linkedin"></i>
                            <h6>Linkdin</h6>
                            <span class="counter">12546</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-12 col-lg-5">
                <div class="blog-posted">
                    <!-- Single Blog Post -->
                    <div class="blog-posted-item">
                        <div class="posted-date">
                            <div class="post-date-box">
                                <h6>19</h6>
                                <h4>Aug</h4>
                            </div>
                        </div>
                        <h5>By conducting various inter investigation activities and implementing risk. </h5>
                        <ul class="flat-list">
                            <li><a href="#" class="brand-color"><i class="fa fa-user"></i> By Admin</a></li>
                            <li><a href="#" class="dark"><i class="fa fa-comments brand-color"></i> 12</a></li>
                            <li><a href="#" class="dark"><i class="fa fa-thumbs-up brand-color"></i> 38</a></li>
                        </ul>
                    </div>
                    <!-- Single Blog Post -->
                    <div class="blog-posted-item">
                        <div class="posted-date">
                            <div class="post-date-box">
                                <h6>19</h6>
                                <h4>Aug</h4>
                            </div>
                        </div>
                        <h5>By conducting various inter investigation activities and implementing risk. </h5>
                        <ul class="flat-list">
                            <li><a href="#" class="brand-color"><i class="fa fa-user"></i> By Admin</a></li>
                            <li><a href="#" class="dark"><i class="fa fa-comments brand-color"></i> 12</a></li>
                            <li><a href="#" class="dark"><i class="fa fa-thumbs-up brand-color"></i> 38</a></li>
                        </ul>
                    </div>
                    <!-- Single Blog Post -->
                    <div class="blog-posted-item">
                        <div class="posted-date">
                            <div class="post-date-box">
                                <h6>19</h6>
                                <h4>Aug</h4>
                            </div>
                        </div>
                        <h5>By conducting various inter investigation activities and implementing risk. </h5>
                        <ul class="flat-list">
                            <li><a href="#" class="brand-color"><i class="fa fa-user"></i> By Admin</a></li>
                            <li><a href="#" class="dark"><i class="fa fa-comments brand-color"></i> 12</a></li>
                            <li><a href="#" class="dark"><i class="fa fa-thumbs-up brand-color"></i> 38</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Social-media Part End -->