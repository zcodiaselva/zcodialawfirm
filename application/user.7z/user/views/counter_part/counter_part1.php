<!-- Counter-3 Part Start -->
    <section class="counter-3-part section-p counter-3-s2">
        <div class="container">
            <div class="row">
                <!-- Single Counterup -->
                <div class="col-md-3 col-6 text-center">
                    <div class="counter-3-item">
                        <div class="number-box">
                            <i class="flaticon-customer"></i>
                            <h2 class="white counter">125</h2>
                        </div>
                        <h3 class="font-size-16">Satisfied Clients</h3>
                    </div>
                </div>
                <!-- Single Counterup -->
                <div class="col-md-3 col-6 text-center">
                    <div class="counter-3-item">
                        <div class="number-box">
                            <i class="flaticon-cells"></i>
                            <h2 class="white counter">25</h2>
                        </div>
                        <h3 class="font-size-16">Year Experience</h3>
                    </div>
                </div>
                <!-- Single Counterup -->
                <div class="col-md-3 col-6 mt-4 mt-md-0 text-center">
                    <div class="counter-3-item">
                        <div class="number-box">
                            <i class="flaticon-project-manager"></i>
                            <h2 class="white counter">925</h2>
                        </div>
                        <h3 class="font-size-16">Project Done</h3>
                    </div>
                </div>
                <!-- Single Counterup -->
                <div class="col-md-3 col-6 mt-4 mt-md-0 text-center">
                    <div class="counter-3-item">
                        <div class="number-box">
                            <i class="flaticon-smiling-emoticon-square-face"></i>
                            <h2 class="white counter">725</h2>
                        </div>
                        <h3 class="font-size-16">Happy Clients</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Counter-3 Part End -->