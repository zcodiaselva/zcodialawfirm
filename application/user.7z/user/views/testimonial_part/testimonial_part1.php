<!-- Testimonial-3 Part Start -->
    <section class="testimonial-3-part section-p-2">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="section-head-3-1">
                        <h2 class="white">Client <span>Stories</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-10 offset-1">
                    <div class="swiper-container testimonial-3-slider" data-swiper-config='{"loop": true, "effect": "slide", "speed": 2000, "autoplay": 5000,"slidesPerView": 1,"paginationClickable": true}'>
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <!-- Slides -->
                            <div class="swiper-slide testimonial-3-item">
                                <div class="person-3-comment">
                                    <i class="fa fa-quote-left"></i>
                                    <h3>“ Thanks to this legal company, I got all my property back and got mytation restored. The team of professional lawyers will surely  to this legal company, I got all my prsucceed in your lawyers will surely case too.”</h3>
                                </div>
                                <div class="person-3-detail">
                                    <h2>Thomas Anders</h2>
                                    <p>Founder & CEO</p>
                                </div>
                            </div>
                            <div class="swiper-slide testimonial-3-item">
                                <div class="person-3-comment">
                                    <i class="fa fa-quote-left"></i>
                                    <h3>“ Thanks to this legal company, I got all my property back and got mytation restored. The team of professional lawyers will surely  to this legal company, I got all my prsucceed in your lawyers will surely case too.”</h3>
                                </div>
                                <div class="person-3-detail">
                                    <h2>Thomas Anders</h2>
                                    <p>Founder & CEO</p>
                                </div>
                            </div>
                            <div class="swiper-slide testimonial-3-item">
                                <div class="person-3-comment">
                                    <i class="fa fa-quote-left"></i>
                                    <h3>“ Thanks to this legal company, I got all my property back and got mytation restored. The team of professional lawyers will surely  to this legal company, I got all my prsucceed in your lawyers will surely case too.”</h3>
                                </div>
                                <div class="person-3-detail">
                                    <h2>Thomas Anders</h2>
                                    <p>Founder & CEO</p>
                                </div>
                            </div>
                        </div>
                        <!-- If we need pagination -->
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Testimonial-3 Part End -->