<!-- About-4 Part Start -->
    <div class="about-4-part section-p-2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-xl-6">
                    <div class="about-4-img">
                        <img src="images/about-4.png" alt="">
                    </div>
                </div>
                <div class="col-md-8 col-xl-6">
                    <div class="about-4-des">
                        <div class="section-head-2-1">
                            <h2><span>Welcome</span> To Legal Help</h2>
                            <p>Dummy text of the printing and typesetting industry Ipsum has been the industry's standard unknown</p>
                        </div>
                        <div id="accordion-4" class="about-4-accodian">
                            <div class="accodian-4-item">
                                <div class="accodian-4-head" data-toggle="collapse" data-target="#collapse-4-One" >
                                    <h5 class="bold">We are served since 93 years to our clients with trust and we are happy.</h5>
                                </div>
                                <div id="collapse-4-One" class="accodian-4-result collapse" data-parent="#accordion-4">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>
                            <div class="accodian-4-item active">
                                <div class="accodian-4-head" data-toggle="collapse" data-target="#collapse-4-Two" >
                                    <h5 class="bold">High Quality Performanceyears.</h5>
                                </div>
                                <div id="collapse-4-Two" class="accodian-4-result collapse show" data-parent="#accordion-4">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>
                            <div class="accodian-4-item">
                                <div class="accodian-4-head" data-toggle="collapse" data-target="#collapse-4-three" >
                                    <h5 class="bold">Experience the beeWe try to make the world a secure place to live</h5>
                                </div>
                                <div id="collapse-4-three" class="accodian-4-result collapse" data-parent="#accordion-4">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>
                            <div class="accodian-4-item">
                                <div class="accodian-4-head" data-toggle="collapse" data-target="#collapse-4-four" >
                                    <h5 class="bold">Talk to one of our attorneys today! </h5>
                                </div>
                                <div id="collapse-4-four" class="accodian-4-result collapse" data-parent="#accordion-4">
                                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About-4 Part End -->